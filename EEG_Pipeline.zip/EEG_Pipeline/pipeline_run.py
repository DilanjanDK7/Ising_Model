from Utils.localization_func import *
from Utils.Ploting_functions import *
from Utils.QM_Model_functions import *
from Utils.Network_Extraction_TPM import *

###### fsAverage Template Common Files ######
mri_subject='fsaverage'
mri_folder='/home/brainlab-qm/FSL/Subjects_1'
bem_dir='/home/brainlab-qm/EEG_test/Output/Arci_test3/bem.fif' ### same for same template
# source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif'  # same for same template4
source_space=None
stc_file='/home/brainlab-qm/EEG_test/Output/Arci_test3/source'

#################3 Iteratable ###########
eeg_file='/home/brainlab-qm/EEG_test/Arci_test.set'
output_folder='/home/brainlab-qm/EEG_test/Output'
eeg_subject='Arci_test3'
forward_model_path=None
qm_save_path=os.path.join(output_folder,eeg_subject,"QM_model/")
### Has to be calculated everytime
#Coregistration will be caculated everytime
#Noise Covariance will be calculated everytime
folder=os.path.join(output_folder,eeg_subject)

######### Parts to Run #######
perform_source_localization= True
QM_model=True
Network_extraction = True

if perform_source_localization:
    ############################## Source Reconstruction ###################
    if stc_file==None:
        stc= eeg_pipeline(eeg_file, output_folder,eeg_subject,mri_subject,mri_folder,bem_dir=bem_dir,Montage=None,source_space=source_space, forward_model_path=forward_model_path, normalization_method='sloreta')
        stc.save(folder+'/source',overwrite=True)
    else:
        stc = mne.read_source_estimate(stc_file)
        print("File Read")

    x,y,z=get_coordinates_mni(stc,subject=mri_subject, subjects_dir=mri_folder)

    print("Source localization Done")



