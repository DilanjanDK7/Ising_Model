import gc
import os
import mne
import matplotlib.pyplot as plt
import numpy as np
from mne.coreg import Coregistration
from mne.minimum_norm import make_inverse_operator
import logging

######################## Basic Functions ##################
def find_files_by_extension(folder_path, file_extension):
    file_list = []
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith(file_extension):
                file_path = os.path.join(root, file)
                file_list.append((file, file_path))
    return file_list


def makedir2(path):
    import os
    if not os.path.exists(path):
        os.mkdir(path)
        return True
    return True
def read_eeg_file(eeg_file):
    """
    Reads EEG data from file.

    Parameters:
    ----------
    eeg_file : str
        Path to EEG file.

    Returns:
    -------
    raw : mne.Raw
        The raw EEG data.
    """
    # Determine file type based on extension
    file_ext = eeg_file.split('.')[-1]
    if file_ext == 'fif':
        raw = mne.io.read_raw_fif(eeg_file)
    elif file_ext == 'edf':
        raw = mne.io.read_raw_edf(eeg_file)
    elif file_ext == 'bdf':
        raw = mne.io.read_raw_bdf(eeg_file)
    elif file_ext == 'set':
        raw = mne.io.read_raw_eeglab(eeg_file)
    elif file_ext == 'vhdr':
        raw = mne.io.read_raw_brainvision(eeg_file)
    elif file_ext == '.gdf':
        raw = mne.io.read_raw_gdf(eeg_file)
    elif file_ext == '.cnt':
        raw = mne.io.read_raw_cnt(eeg_file)
    elif file_ext =='.csv' :
        raw = np.loadtxt(eeg_file)
    else:
        raise ValueError(f"Unsupported file format: {file_ext}")
    return raw

def get_info_variables(info):
    nchan = info['nchan']
    ch_names = info['ch_names']
    sfreq = info['sfreq']
    description = info['description']
    bads = info['bads']
    ch_types = info['ch_types']
    dig = info['dig']
    projs = info['projs']
    highpass = info['highpass']
    lowpass = info['lowpass']
    events = info['events']

    return nchan, ch_names, sfreq, description, bads, ch_types, dig, projs, highpass, lowpass, events

def save_stc_as_nifti(stc, src,save_dir, fname='source_estimate.nii.gz'):
    """
    Saves the source estimate as a NIfTI file.

    Parameters:
    ----------
    stc : mne.SourceEstimate
        The source estimate.
    subject : str
        The subject name.
    mri_subjects_dir : str
        The MRI subjects directory.
    fname : str
        The file name.

    Returns:
    -------
    None
    """
    # Save as NIfTI
    stc.save_as_volume(fname=os.path.join(save_dir, fname), src=src, mri_resolution=False,format='nifti1',overwrite=True,verbose=True)

    return logging.info(f"Saved source estimate as NIfTI file: {fname}")

def get_montage(channel_file=None,Use_builtin=False,channel_name=None):
    """
    Get Montages of files
    Possible default :['standard_1005',
 'standard_1020',
 'standard_alphabetic',
 'standard_postfixed',
 'standard_prefixed',
 'standard_primed',
 'biosemi16',
 'biosemi32',
 'biosemi64',
 'biosemi128',
 'biosemi160',
 'biosemi256',
 'easycap-M1',
 'easycap-M10',
 'EGI_256',
 'GSN-HydroCel-32',
 'GSN-HydroCel-64_1.0',
 'GSN-HydroCel-65_1.0',
 'GSN-HydroCel-128',
 'GSN-HydroCel-129',
 'GSN-HydroCel-256',
 'GSN-HydroCel-257',
 'mgh60',
 'mgh70',
 'artinis-octamon',
 'artinis-brite23',
 'brainproducts-RNP-BA-128']

    To find channel list in MNE    mne.channels.get_builtin_montages()

    :param channel_file:
    :param Use_builtin:
    :param channel_name:
    :return:
    """
    if (channel_file==None and Use_builtin==True):
        montage =mne.channels.make_standard_montage(channel_name)
    elif(Use_builtin==False):
        montage=mne.channels.read_custom_montage(channel_file)
    return montage


def set_eeg_montage(raw,montage):
    raw.set_montage(montage)

    return raw

def plot_preprocessing_steps(raw, events=None, event_id=None):
    """
    Creates plots for the different preprocessing steps.

    Parameters:
    ----------
    raw : mne.Raw
        The raw EEG data.
    events : numpy array
        The events array.
    event_id : dict
        The event ID dictionary.

    Returns:
    -------
    None
    """
    # Plot raw data
    raw.plot(scalings='auto', duration=20, n_channels=30)

    # Apply high-pass filter
    raw.filter(l_freq=1.0, h_freq=None, fir_design='firwin')
    raw.plot(scalings='auto', duration=20, n_channels=30)

    # Detect and mark bad channels
    raw.info['bads'] = []
    raw.plot(scalings='auto', duration=20, n_channels=30)
    raw.info['bads'] = ['Fp1']

    # Apply notch filter
    raw.notch_filter(freqs=50, notch_widths=2)
    raw.plot(scalings='auto', duration=20, n_channels=30)

    # Epoch data
    if (events==None):
        print('No events. Plotting for Raw file')
    else:
        epochs = mne.Epochs(raw, events, event_id, tmin=-0.2, tmax=0.5, baseline=(None, 0), preload=True)
        epochs.plot(scalings='auto', n_epochs=10)

        # Remove baseline and plot
        epochs.apply_baseline(baseline=(None, 0))
        epochs.plot(scalings='auto', n_epochs=10)

        # Plot power spectral density
        epochs.plot_psd(fmax=40)

        # Plot topographic maps
        evoked = epochs.average()
        evoked.plot_topomap(times=[0.05, 0.1, 0.15], ch_type='eeg', outlines='skirt')

    plt.show()


def get_coordinates_mni(stc,subject,subjects_dir,fro=None,to=None):
    """
       https://mne.tools/stable/generated/mne.vertex_to_mni.html
    :param stc:
    :param subject:
    :param subjects_dir:
    :param fro:
    :param to:
    :return:
    """
    vertices=stc.lh_vertno
    hemis=0
    coord =mne.vertex_to_mni(vertices, hemis, subject, subjects_dir, verbose=True)

    vertices2=stc.rh_vertno
    hemis2=1
    coord2=mne.vertex_to_mni(vertices2, hemis2, subject, subjects_dir, verbose=True)
    coords_all=np.append(coord,coord2,axis=0)
    # coord.transforms.Transform(fro, to, trans=None)
    # """https://mne.tools/dev/generated/mne.transforms.Transform.html"""
    x = coords_all[:, 0]
    y = coords_all[:, 1]
    z = coords_all[:, 2]
    return x,y,z

def get_coordinates_mni_volume(stc,subject,subjects_dir,fro=None,to=None):
    """
       https://mne.tools/stable/generated/mne.vertex_to_mni.html
    :param stc:
    :param subject:
    :param subjects_dir:
    :param fro:
    :param to:
    :return:
    """
    vertices=stc.vertices[0]
    hemis=0
    coord =mne.vertex_to_mni(vertices, hemis, subject, subjects_dir, verbose=True)

    coords_all=np.append(coord,coord2,axis=0)
    # coord.transforms.Transform(fro, to, trans=None)
    # """https://mne.tools/dev/generated/mne.transforms.Transform.html"""
    x = coords_all[:, 0]
    y = coords_all[:, 1]
    z = coords_all[:, 2]
    return x,y,z

################################## Source Localization #############################33

def automatic_coregistration(info,mri_subject,mri_subjects_dir,coreg_output_path , fiducials = "estimated",verbose=True):
    #Set up the coregistration model
    # get fiducials from fsaverage

    plot_kwargs = dict(subject=mri_subject, subjects_dir=mri_subjects_dir,
                       surfaces="head-dense", dig=True, eeg='original',
                       meg=[], show_axes=True,mri_fiducials=True,interaction='terrain',
                       coord_frame='auto',verbose=True)
    view_kwargs = dict(azimuth=45, elevation=90, distance=0.6,
                       focalpoint=(0., 0., 0.))
    coreg = Coregistration(info, subject=mri_subject, subjects_dir=mri_subjects_dir, fiducials=fiducials)
    # fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)


    #Initial fit with fiducials
    coreg.fit_fiducials(verbose=True)
    # fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)

    #Refining with ICP
    coreg.fit_icp(n_iterations=6, nasion_weight=2., verbose=True)
    # fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)

    #Omitting bad points
    coreg.omit_head_shape_points(distance=5. / 1000)  # distance is in meters

    #Final coregistration fit
    coreg.fit_icp(n_iterations=20, nasion_weight=10., verbose=True)
    # fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)
    # mne.viz.set_3d_view(fig, **view_kwargs)

    dists = coreg.compute_dig_mri_distances() * 1e3  # in mm
    print(
        f"Distance between HSP and MRI (mean/min/max):\n{np.mean(dists):.2f} mm "
        f"/ {np.min(dists):.2f} mm / {np.max(dists):.2f} mm"
    )

    # Saving the Coregistration fit
    coreg_output_path=os.path.join(coreg_output_path,'coreg-trans.fif')
    mne.write_trans(coreg_output_path, coreg.trans,overwrite=True)
    return coreg.trans


############ Common (Template Files) ##########
def get_bem_model(output_folder,bem=None,subject=None,ico=None,subjects_dir=None,verbose=True,solver='openmeeg'):
    """
    This function Primilary is configured to use the "OpenMEEG solver to obtain the BEM model"
    solver = 'openmeeg' uses openmeeg
    solver = 'mne' uses MNE_Python
    :param bem: If file available ,Supply here
    :param subject:The subject.
    :param ico:The surface ico downsampling to use, e.g. 5=20484, 4=5120, 3=1280. If None, no subsampling is applied.
    :param subjects_dir: The path to the directory containing the FreeSurfer subjects reconstructions.
    :return:
    """
    if (bem==None):
        conductivity = (0.3, 0.006, 0.3)  # for three layers
        try:
            model = mne.make_bem_model(subject=subject, ico=ico,conductivity=conductivity,subjects_dir=subjects_dir,verbose=True)
        except:
            mne.set_config('FREESURFER_HOME','/usr/local/freesurfer/7.3.2/')
            # mne.get_config()
            mne.bem.make_watershed_bem(subject=subject,subjects_dir=subjects_dir,verbose=True,overwrite=False,atlas=False,gcaatlas=False,show=True,preflood=None, brainmask='ws.mgz')
            model = mne.make_bem_model(subject=subject, ico=ico,conductivity=conductivity,subjects_dir=subjects_dir,verbose=True)

        mne.write_bem_surfaces(output_folder+"/surface", model, overwrite=True, verbose=True)
        bem = mne.make_bem_solution(model,solver=solver,verbose=verbose)
            # Create BEM surfaces
        # surfaces = mne.make_bem_surfaces(model, conductivity=conductivity, subjects_dir=subjects_dir)

        mne.write_bem_solution(output_folder+"/bem.fif", bem, overwrite=True, verbose=True)
    else:
        bem=mne.read_bem_solution(fname=bem, verbose=verbose)
        # bem=mne.read_bem_surfaces(fname=bem, patch_stats=False, s_id=None, on_defects='raise', verbose=verbose)
        # mne.write_bem_surfaces(fname, surfs, overwrite=False, *, verbose=None)

    plot_bem_kwargs = dict(
        subject=subject, subjects_dir=subjects_dir,
        brain_surfaces='white', orientation='coronal',
        slices=[50, 100, 150, 200])
    # mne.viz.plot_bem(**plot_bem_kwargs)
    return bem

def compute_source_space(subject,bem,subject_dir,spacing=5,mri='T1.mgz',sphere=None,source_space=None,mindist=4.0,volume_label=None,verbose=True,add_interpolator=True,sphere_units='m'):
    """
    :param subject:
    :param mri:    The filename of an MRI volume (mgh or mgz) to create the interpolation matrix over. Source estimates obtained in the volume source space can then be morphed onto the MRI volume using this interpolator. If pos is a dict, this cannot be None. If subject name is provided, pos is a float or volume_label are not provided then the mri parameter will default to ‘T1.mgz’ or aseg.mgz, respectively, else it will stay None.
    :param bem:
    :param subject_dir:
    :param pos:
    :param sphere:
    :param surface_file:
    :param mindist:
    :param volume_label:
    :param verbose:
    :param add_interpolator:
    :param sphere_units:
    :return:
    """


    if source_space==None:
        src = mne.setup_source_space(subject, spacing=spacing, surface='white', subjects_dir=subject_dir, add_dist=True, n_jobs=-1, verbose=True)
        # src =mne.setup_source_space(subject=subject,spacing=spacing, mri='T1.mgz', sphere=sphere, bem=bem, surface=surface_file, mindist=mindist, exclude=0.0, subjects_dir=subject_dir, volume_label=volume_label, add_interpolator=add_interpolator, sphere_units=sphere_units, single_volume=False, verbose=verbose)
        path_save=os.path.join(subject_dir,subject,'Pipeline/')
        mne.write_source_spaces(path_save+"source-src.fif", src, overwrite=True, verbose=True)
    else:
        # Load the surface mesh for the given subject
        # surface = mne.read_surface(f"{subject_dir}/{subject}/surf/lh.white")
        src=mne.read_source_spaces(source_space, patch_stats=False, verbose=True)
        # src = mne.setup_source_space(subject, spacing=spacing, surface='white', subjects_dir=subject_dir, add_dist=True, n_jobs=None, verbose=True)
        # Compute the source space using the surface mesh
        # src =mne.setup_volume_source_space(subject=subject, pos=pos, mri='T1.mgz', sphere=sphere, bem=bem, surface=surface_file, mindist=mindist, exclude=0.0, subjects_dir=subject_dir, volume_label=volume_label, add_interpolator=add_interpolator, sphere_units=sphere_units, single_volume=False, verbose=verbose)
    return src

def compute_volume_source_space(subject,bem,subject_dir,spacing=5,mri='T1.mgz',sphere=None,source_space=None,mindist=4.0,volume_label=None,verbose=True,add_interpolator=True,sphere_units='m'):

    if source_space==None:
        src = mne.setup_volume_source_space(subject=subject, pos=5.0, mri='T1.mgz', sphere=None, bem=bem, surface=None, mindist=5.0, exclude=0.0, subjects_dir=subject_dir, volume_label=None, add_interpolator=True, sphere_units='m', single_volume=False, verbose=True)
        # src =mne.setup_source_space(subject=subject,spacing=spacing, mri='T1.mgz', sphere=sphere, bem=bem, surface=surface_file, mindist=mindist, exclude=0.0, subjects_dir=subject_dir, volume_label=volume_label, add_interpolator=add_interpolator, sphere_units=sphere_units, single_volume=False, verbose=verbose)
        path_save=os.path.join(subject_dir,subject,'Pipeline/')
        mne.write_source_spaces(path_save+"source_vol-src.fif", src, overwrite=True, verbose=True)
    else:
        # Load the surface mesh for the given subject
        # surface = mne.read_surface(f"{subject_dir}/{subject}/surf/lh.white")
        src=mne.read_source_spaces(source_space, patch_stats=False, verbose=True)
        # src = mne.setup_source_space(subject, spacing=spacing, surface='white', subjects_dir=subject_dir, add_dist=True, n_jobs=None, verbose=True)
        # Compute the source space using the surface mesh
        # src =mne.setup_volume_source_space(subject=subject, pos=pos, mri='T1.mgz', sphere=sphere, bem=bem, surface=surface_file, mindist=mindist, exclude=0.0, subjects_dir=subject_dir, volume_label=volume_label, add_interpolator=add_interpolator, sphere_units=sphere_units, single_volume=False, verbose=verbose)
    return src

################### Subject Specific/ Individual Calculations ######
def compute_noise_covariance(raw,cv=3,verbose=True):
    """Compute noise covariance matrix from raw data using MNE-Python.
    ############# This method should be thoroughly tested and validated for accuracy ######
    Args:
        raw (mne.io.Raw): Raw data object containing the EEG signals.
        CV= cross-validation

    Returns:
        noise_cov (mne.cov.Covariance): Noise covariance matrix.

    """
    # Define parameters for covariance computation
    method = 'empirical'  # Use empirical covariance estimation
    tmin, tmax = 0, None  # Use all time points
    picks = mne.pick_types(raw.info, meg=False, eeg=True, stim=False, eog=False,
                           exclude='bads')  # Use only EEG channels, exclude bad channels

    # Compute the noise covariance matrix
    noise_cov = mne.compute_raw_covariance(raw, tmin=tmin, tmax=tmax, method=method, picks=picks,cv=cv,verbose=verbose)

    return noise_cov

def compute_forward_model(info,subject_dir,src,subject,output_folder,bem=None,surfaces=None,trans=None,fwd_file=None,mindist=5, n_jobs=1):
    """
    Calculates the forward model using FreeSurfer.

    Parameters:
    ----------
    eeg_file : str
        Path to EEG file.
    subject_dir : str
        Path to subject directory.
    fwd_file : str or None, optional (default=None)
        Path to forward model file. If None, the forward model is saved in the subject directory.
    conductivity : tuple, optional (default=(0.3,))
        The conductivity values to use for the BEM model.
    n_jobs : int, optional (default=1)
        The number of jobs to run in parallel when calculating the forward model.

    Returns:
    -------
    fwd : mne.Forward
        The forward model.
    """
    # Define MRI file paths for subject
    mri_dir = os.path.join(subject_dir, 'mri')
    bem_dir = os.path.join(mri_dir, 'bem')
    # Compute forward model
    fwd = mne.make_forward_solution(info, trans=trans, src=src, bem=bem, meg=False,
                                    eeg=True, mindist=mindist,verbose=True,n_jobs=1)
    # fwd2= mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, copy=True, use_cps=True, verbose=True)
    # set the copy to True if you want to take the inital forward solution out
    # Save forward model to file
    logging.info("forward file computed- within function")
    if fwd_file is None:
        fwd_file = os.path.join(output_folder, 'EEG_forward-fwd.fif')
        mne.write_forward_solution(fwd_file, fwd, overwrite=True)
        logging.info("forward file saved")
        #This is subject dependent, Hence do not save in Commom 'Pipeline' folder
        # path_save = os.path.join(subject_dir, subject, 'Pipeline/')
        # mne.write_forward_solution(path_save+'EEG_forward-fwd.fif', fwd, overwrite=True)
    gc.collect()
    return fwd

def compute_forward_model_volume(info,subject_dir,src,subject,output_folder,bem=None,surfaces=None,trans=None,fwd_file=None,mindist=5, n_jobs=1):
    """
    Calculates the forward model using FreeSurfer.

    Parameters:
    ----------
    eeg_file : str
        Path to EEG file.
    subject_dir : str
        Path to subject directory.
    fwd_file : str or None, optional (default=None)
        Path to forward model file. If None, the forward model is saved in the subject directory.
    conductivity : tuple, optional (default=(0.3,))
        The conductivity values to use for the BEM model.
    n_jobs : int, optional (default=1)
        The number of jobs to run in parallel when calculating the forward model.

    Returns:
    -------
    fwd : mne.Forward
        The forward model.
    """
    # Define MRI file paths for subject
    mri_dir = os.path.join(subject_dir, 'mri')
    bem_dir = os.path.join(mri_dir, 'bem')
    # Compute forward model
    fwd = mne.make_forward_solution(info, trans=trans, src=src, bem=bem, meg=False,
                                    eeg=True, mindist=mindist,verbose=True,n_jobs=1)
    # fwd2= mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, copy=True, use_cps=True, verbose=True)
    # set the copy to True if you want to take the inital forward solution out
    # Save forward model to file
    logging.info("forward file computed- within function")
    if fwd_file is None:
        fwd_file = os.path.join(output_folder, 'EEG_forward-fwd.fif')
        mne.write_forward_solution(fwd_file, fwd, overwrite=True)
        logging.info("forward file saved")
        #This is subject dependent, Hence do not save in Commom 'Pipeline' folder
        # path_save = os.path.join(subject_dir, subject, 'Pipeline/')
        # mne.write_forward_solution(path_save+'EEG_forward-fwd.fif', fwd, overwrite=True)
    gc.collect()
    return fwd

def compute_forward_model_mixed(info,subject_dir,src,subject,output_folder,bem=None,surfaces=None,trans=None,fwd_file=None,mindist=5, n_jobs=1):
    """
    Calculates the forward model using FreeSurfer.

    Parameters:
    ----------
    eeg_file : str
        Path to EEG file.
    subject_dir : str
        Path to subject directory.
    fwd_file : str or None, optional (default=None)
        Path to forward model file. If None, the forward model is saved in the subject directory.
    conductivity : tuple, optional (default=(0.3,))
        The conductivity values to use for the BEM model.
    n_jobs : int, optional (default=1)
        The number of jobs to run in parallel when calculating the forward model.

    Returns:
    -------
    fwd : mne.Forward
        The forward model.
    """
    # Define MRI file paths for subject
    mri_dir = os.path.join(subject_dir, 'mri')
    bem_dir = os.path.join(mri_dir, 'bem')
    # Compute forward model
    fwd = mne.make_forward_solution(info, trans=trans, src=src, bem=bem, meg=False,
                                    eeg=True, mindist=mindist,verbose=True,n_jobs=1)
    # fwd2= mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, copy=True, use_cps=True, verbose=True)
    # set the copy to True if you want to take the inital forward solution out
    # Save forward model to file
    logging.info("forward file computed- within function")
    if fwd_file is None:
        fwd_file = os.path.join(output_folder, 'EEG_forward-fwd.fif')
        mne.write_forward_solution(fwd_file, fwd, overwrite=True)
        logging.info("forward file saved")
        #This is subject dependent, Hence do not save in Commom 'Pipeline' folder
        # path_save = os.path.join(subject_dir, subject, 'Pipeline/')
        # mne.write_forward_solution(path_save+'EEG_forward-fwd.fif', fwd, overwrite=True)
    gc.collect()
    return fwd


def get_inverse_raw(raw,fwd,noise_cov,subjects_dir,method='sLORETA',snr=3.0,orientation='normal'):
    """
    Parameters:

    evokedEvoked object

        Evoked data.
    inverse_operatorinstance of InverseOperator

        Inverse operator.
    lambda2float

        The regularization parameter.
    method“MNE” | “dSPM” | “sLORETA” | “eLORETA”

        Use minimum norm [1], dSPM (default) [2], sLORETA [3], or eLORETA [4].
    pick_oriNone | “normal” | “vector”

        Options:

            None

                Pooling is performed by taking the norm of loose/free orientations. In case of a fixed source space no norm is computed leading to signed source activity.

            "normal"

                Only the normal to the cortical surface is kept. This is only implemented when working with loose orientations.

            "vector"

                No pooling of the orientations is done, and the vector result will be returned in the form of a mne.VectorSourceEstimate object.

    preparedbool

        If True, do not call prepare_inverse_operator().
    labelLabel | None

        Restricts the source estimates to a given label. If None, source estimates will be computed for the entire source space.
    method_paramsdict | None

        Additional options for eLORETA. See Notes for details.
    :param raw:
    :param fwd:
    :param noise_cov:
    :param subjects_dir:
    :param method:
    :param snr:
    :param orientation:
    :return:
    """
    lambda2 = 1. / snr ** 2
    ####################### The parameters used here for loose and fixed needs to be double checked ##########
    inv = make_inverse_operator(raw.info, fwd, noise_cov,loose='auto',depth=None,fixed='auto',use_cps=True,verbose=True)
    """ Please Read : https://mne.tools/stable/generated/mne.minimum_norm.make_inverse_operator.html"""
    stc= mne.minimum_norm.apply_inverse_raw(raw, inv, lambda2, method=method, label=None, start=None, stop=None, nave=1,
                                       time_func=None, pick_ori="normal", buffer_size=None, prepared=False,
                                       method_params=None, use_cps=True, verbose=True)

    """ Please Read : https://mne.tools/stable/generated/mne.minimum_norm.apply_inverse_raw.html
    Read for Parameters*** Important ****
    pick_orient - "Normal" will keep only the values normal to the cortical surface
    """

    # # Visualize it at the moment of peak activity.
    # vertno_max, time_max = stc.get_peak()
    # surfer_kwargs = dict(
    #     hemi='rh', subjects_dir=subjects_dir,
    #     clim=dict(kind='value', lims=[8, 12, 15]), views='lateral',
    #     initial_time=time_max, time_unit='s', size=(800, 800), smoothing_steps=10)
    # brain = stc.plot(**surfer_kwargs)
    # brain.add_foci(vertno_max, coords_as_verts=True, hemi='rh', color='blue',
    #                scale_factor=0.6, alpha=0.5)
    # brain.add_text(0.1, 0.9, 'dSPM (plus location of maximal activation)', 'title',
    #                font_size=14)
    return stc

def get_inverse_raw_volume(raw,fwd,noise_cov,subjects_dir,method='sLORETA',snr=3.0,orientation='normal',Time_limit=None):
    """
    Parameters:

    evokedEvoked object

        Evoked data.
    inverse_operatorinstance of InverseOperator

        Inverse operator.
    lambda2float

        The regularization parameter.
    method“MNE” | “dSPM” | “sLORETA” | “eLORETA”

        Use minimum norm [1], dSPM (default) [2], sLORETA [3], or eLORETA [4].
    pick_oriNone | “normal” | “vector”

        Options:

            None

                Pooling is performed by taking the norm of loose/free orientations. In case of a fixed source space no norm is computed leading to signed source activity.

            "normal"

                Only the normal to the cortical surface is kept. This is only implemented when working with loose orientations.

            "vector"

                No pooling of the orientations is done, and the vector result will be returned in the form of a mne.VectorSourceEstimate object.

    preparedbool

        If True, do not call prepare_inverse_operator().
    labelLabel | None

        Restricts the source estimates to a given label. If None, source estimates will be computed for the entire source space.
    method_paramsdict | None

        Additional options for eLORETA. See Notes for details.
    :param raw:
    :param fwd:
    :param noise_cov:
    :param subjects_dir:
    :param method:
    :param snr:
    :param orientation:
    :return:
    """
    lambda2 = 1. / snr ** 2
    ####################### The parameters used here for loose and fixed needs to be double checked ##########
    inv = make_inverse_operator(raw.info, fwd, noise_cov,loose='auto',depth=None,fixed='auto',use_cps=True,verbose=True)
    """ Please Read : https://mne.tools/stable/generated/mne.minimum_norm.make_inverse_operator.html"""
    stc= mne.minimum_norm.apply_inverse_raw(raw, inv, lambda2, method=method, label=None, start=None, stop=Time_limit, nave=1,
                                       time_func=None, pick_ori=None, buffer_size=20000, prepared=False,
                                       method_params=None, use_cps=True, verbose=True)
    #Above condition pick_ori==None means the normalised activity is taken while pick_ori=="vector" givens activity in all directions
    #Pooling is performed by taking the norm of loose/free orientations -- pick_ori==None

    """ Please Read : https://mne.tools/stable/generated/mne.minimum_norm.apply_inverse_raw.html
    Read for Parameters*** Important ****
    pick_orient - "Normal" will keep only the values normal to the cortical surface
    """

    # # Visualize it at the moment of peak activity.
    # vertno_max, time_max = stc.get_peak()
    # surfer_kwargs = dict(
    #     hemi='rh', subjects_dir=subjects_dir,
    #     clim=dict(kind='value', lims=[8, 12, 15]), views='lateral',
    #     initial_time=time_max, time_unit='s', size=(800, 800), smoothing_steps=10)
    # brain = stc.plot(**surfer_kwargs)
    # brain.add_foci(vertno_max, coords_as_verts=True, hemi='rh', color='blue',
    #                scale_factor=0.6, alpha=0.5)
    # brain.add_text(0.1, 0.9, 'dSPM (plus location of maximal activation)', 'title',
    #                font_size=14)
    return stc

def eeg_pipeline(eeg_file, output_folder,eeg_subject,mri_subject,mri_folder,bem_dir=None,Montage=None, forward_model_path=None, source_space=None,normalization_method='sloreta',solver='openmeeg',verbose=True):
    subject=mri_subject
    subject_dir=mri_folder
    data_output_path=os.path.join(output_folder,eeg_subject+ '/')
    makedir2(data_output_path)

    ################   Read file #########
    raw = read_eeg_file(eeg_file)
    info=raw.info

    ########## Get Co-registration ######### This file depends on individual subject and has to be calculated each run
    trans=automatic_coregistration(info,mri_subject,subject_dir,coreg_output_path=data_output_path, fiducials = "estimated",verbose=True)

    ######### Loading BEM file/ Surface ######## Depends in MRI and can be the same for a given template
    bem = get_bem_model(data_output_path,bem=bem_dir,subject=mri_subject,ico=4,subjects_dir=mri_folder,verbose=True,solver=solver)
    logging.info("Bem Surfaces Computed")
    #### Computing Source-space ####    Depends on MRI and parameters can be same for a given template ** refine template to specifications
    src = compute_source_space(subject,bem,subject_dir,spacing=5,sphere=None,mindist=4.0,volume_label=None,verbose=True,add_interpolator=True,sphere_units='m',source_space=source_space)
    gc.collect()
    logging.info("Source space Computed")
    #### Forward Model ####  ############ Has to be calculated everytime since it depends in subject and coregistration .....
    if forward_model_path is None:
        fwd = compute_forward_model(info,subject_dir,src,subject=mri_subject,output_folder=data_output_path,bem=bem,surfaces=None,trans=trans,fwd_file=None,mindist=4, n_jobs=1)
        logging.info("forward Model computed")
    else:
        fwd = mne.read_forward_solution(forward_model_path)
        fwd = mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, copy=False, use_cps=True, verbose=True)
        logging.info("foward model loaded")
    ##### Noise Covariance #####  Calculated every time
    noise_cov=compute_noise_covariance(raw,cv=3)
    logging.info("Noise Covariance computed")
    ##### Inverse Model ###### Calculated every time

    """
    Because of error :ValueError: EEG average reference (using a projector) is mandatory for modeling, use the method set_eeg_reference(projection=True)
    average reference projection is set here ###### check the reasoning ... Important ....
    """
    raw.set_eeg_reference(projection=True)
    logging.info("Reloading all Files")
    inv =get_inverse_raw(raw,fwd,noise_cov,subject_dir,method='sLORETA',snr=3.0,orientation='normal')
    logging.info("inverse calculated")
    del raw,fwd,src,bem,trans,info
    logging.info("Temporary Variables deleted")
    return inv

def eeg_pipeline_volume(eeg_file, output_folder,eeg_subject,mri_subject,mri_folder,bem_dir=None,Montage=None, forward_model_path=None, source_space=None,Time_limit=None,normalization_method='sloreta',solver='openmeeg',verbose=True):
    subject=mri_subject
    subject_dir=mri_folder
    data_output_path=os.path.join(output_folder,eeg_subject+ '/')
    makedir2(data_output_path)

    ################   Read file #########
    raw = read_eeg_file(eeg_file)
    info=raw.info

    ########## Get Co-registration ######### This file depends on individual subject and has to be calculated each run
    trans=automatic_coregistration(info,mri_subject,subject_dir,coreg_output_path=data_output_path, fiducials = "estimated",verbose=True)

    ######### Loading BEM file/ Surface ######## Depends in MRI and can be the same for a given template
    bem = get_bem_model(data_output_path,bem=bem_dir,subject=mri_subject,ico=4,subjects_dir=mri_folder,verbose=True,solver=solver)
    logging.info("Bem Surfaces Computed")
    #### Computing Source-space ####    Depends on MRI and parameters can be same for a given template ** refine template to specifications
    src = compute_volume_source_space(subject,bem,subject_dir,spacing=5,sphere=None,mindist=4.0,volume_label=None,verbose=True,add_interpolator=True,sphere_units='m',source_space=source_space)
    gc.collect()
    logging.info("Source space Computed")
    #### Forward Model ####  ############ Has to be calculated everytime since it depends in subject and coregistration .....
    if forward_model_path is None:
        fwd = compute_forward_model_volume(info,subject_dir,src,subject=mri_subject,output_folder=data_output_path,bem=bem,surfaces=None,trans=trans,fwd_file=None,mindist=4, n_jobs=1)
        logging.info("forward Model computed")
    else:
        fwd = mne.read_forward_solution(forward_model_path)
        fwd = mne.convert_forward_solution(fwd, surf_ori=True, force_fixed=True, copy=False, use_cps=True, verbose=True)
        logging.info("foward model loaded")
    ##### Noise Covariance #####  Calculated every time
    noise_cov=compute_noise_covariance(raw,cv=3)
    logging.info("Noise Covariance computed")
    ##### Inverse Model ###### Calculated every time

    """
    Because of error :ValueError: EEG average reference (using a projector) is mandatory for modeling, use the method set_eeg_reference(projection=True)
    average reference projection is set here ###### check the reasoning ... Important ....
    """
    raw.set_eeg_reference(projection=True)
    logging.info("Reloading all Files")
    inv =get_inverse_raw_volume(raw,fwd,noise_cov,subject_dir,method='sLORETA',snr=3.0,orientation=None,Time_limit=Time_limit)
    logging.info("inverse calculated")
    del raw,fwd,src,bem,trans,info
    logging.info("Temporary Variables deleted")
    return inv


######################################################################

def coordinate_transform(input_frame,output_frame,data=None):
     """
     https://mne.tools/stable/generated/mne.transforms.Transform.html#mne.transforms.Transform
     :param inpuA transform.

Parameters:
frostr | int
The starting coordinate frame. See notes for valid coordinate frames.

tostr | int
The ending coordinate frame. See notes for valid coordinate frames.

transarray of shape (4, 4) | None
The transformation matrix. If None, an identity matrix will be used.

Notes

Valid coordinate frames are 'meg', 'mri', 'mri_voxel', 'head', 'mri_tal', 'ras', 'fs_tal', 'ctf_head', 'ctf_meg', 'unknown'.

Attributes
:
from_str
The “from” frame as a string.

to_str
The “to” frame as a string.

Methodst_frame:
     :param output_frame:
     :param data:
     :return:
     """
     matrix=mne.transforms.Transform(input_frame, output_frame, trans=None)
     return matrix


################################### Not Used but might be helpful later ########




# def coregistration(raw,output_path):
#
#     plot_kwargs = dict(subject=subject, subjects_dir=subjects_dir,
#                        surfaces="head-dense", dig=True, eeg=[],
#                        meg='sensors', show_axes=True,
#                        coord_frame='meg')
#     view_kwargs = dict(azimuth=45, elevation=90, distance=0.6,
#                        focalpoint=(0., 0., 0.))
#     fiducials = "estimated"  # get fiducials from fsaverage
#     coreg = Coregistration(info, subject, subjects_dir, fiducials=fiducials)
#     fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)
#     coreg.fit_fiducials(verbose=True)
#     fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)
#     coreg.fit_icp(n_iterations=6, nasion_weight=2., verbose=True)
#     fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)
#     coreg.omit_head_shape_points(distance=5. / 1000)  # distance is in meters
#     coreg.fit_icp(n_iterations=20, nasion_weight=10., verbose=True)
#     fig = mne.viz.plot_alignment(info, trans=coreg.trans, **plot_kwargs)
#     mne.viz.set_3d_view(fig, **view_kwargs)
#
#     dists = coreg.compute_dig_mri_distances() * 1e3  # in mm
#     print(
#         f"Distance between HSP and MRI (mean/min/max):\n{np.mean(dists):.2f} mm "
#         f"/ {np.min(dists):.2f} mm / {np.max(dists):.2f} mm"
#     )
#     mne.write_trans(output_path+'trans.fif', coreg.trans)
#     return coreg.trans


# def perform_source_estimation(eeg_file, fwd, method='sloreta', snr=3.0, lambda2=None):
#     """
#     Performs source reconstruction using the specified method.
#
#     Parameters:
#     ----------
#     eeg_file : str
#         Path to EEG file.
#     fwd : mne.Forward
#         The forward model.
#     method : str, optional (default='sloreta')
#         The source estimation method to use.
#     snr : float, optional (default=3.0)
#         The signal-to-noise ratio to use for the estimation.
#     lambda2 : float or None, optional (default=None)
#         The regularization parameter to use for the estimation. If None, it is set to 1.0 / snr ** 2.
#
#     Returns:
#     -------
#     stc : mne.SourceEstimate
#         The estimated source activity.
#     """
#     # Load EEG data
#     raw = mne.io.read_raw_eeglab(eeg_file, preload=True)
#
#     # Apply bandpass filter to data
#     raw.filter(l_freq=0.1, h_freq=40)
#
#     # Compute evoked data
#     events = mne.find_events(raw, stim_channel='STI 014')
#     event_id = {'Left': 1, 'Right': 2}
#     tmin = 0.0
#     tmax = 1.0
#     baseline = (None, 0.0)
#     epochs = mne.Epochs(raw, events=events, event_id=event_id, tmin=tmin, tmax=tmax, baseline=baseline, preload=True)
#
#     # Apply source estimation method
#     if lambda2 is None:
#         lambda2 = 1.0 / snr
#     if method == 'sloreta':
#         stc = mne.minimum_norm.apply_inverse_epochs(epochs, fwd, lambda2, method='sloreta', pick_ori=None,
#                                                     return_generator=False)
#     elif method == 'mne':
#         stc = mne.minimum_norm.apply_inverse_epochs(epochs, fwd, lambda2, method='mne', pick_ori=None,
#                                                     return_generator=False)
#     else:
#         raise ValueError('Invalid method specified.')
#
#     return stc

# def get_inverse(raw,fwd,noise_cov,subjects_dir,snr=3,lambda2=None):
#     # Compute the source estimate for the left auditory condition in the sample
#     # dataset.
#     if lambda2 is None:
#         lambda2 = 1.0 / snr
#     inv = make_inverse_operator(raw.info, fwd, noise_cov,loose='auto',fixed=True,verbose=True)
#     stc = apply_inverse(raw, inv, pick_ori=None)
#
#     # Visualize it at the moment of peak activity.
#     _, time_max = stc.get_peak(hemi='lh')
#     brain_fixed = stc.plot(surface='white', subjects_dir=subjects_dir,
#                            initial_time=time_max, time_unit='s', size=(600, 400))
#     fig = mne.viz.set_3d_view(figure=brain_fixed, focalpoint=(0., 0., 50))
#     return stc,inv,fig



# def get_bem_MNE_method(mri_folder,subject,watershed=False,Flash=False):
#     if watershed:
#         bem=mne.bem.make_watershed_bem(subject, subjects_dir=mri_folder, overwrite=False, volume='T1', atlas=False, gcaatlas=False, preflood=None, show=False, copy=True, T1=None, brainmask='ws.mgz', verbose=None)
#     elif Flash:
#         bem =mne.bem.make_flash_bem(subject, overwrite=False, show=True, subjects_dir=mri_folder, copy=True, flash5_img=None, register=True, verbose=None)
#     else:
#         bem=None
#     return bem
# def process_eeg_data(data_folder,mri_folder, output_folder, forward_model=None, normalization_method='sloreta',events=False):
#     """
#     Processes EEG data for multiple subjects.
#
#     Parameters:
#     ----------
#     data_folder : str
#         Path to the data folder.
#     output_folder : str
#         Path to the output folder.
#     forward_model : str or None
#         Path to the forward model file. If None, the forward model will be computed.
#     normalization_method : str
#         The normalization method to use (default is 'sloreta').
#
#     Returns:
#     -------
#     None
#     """
#     # Create output directory
#     os.makedirs(output_folder, exist_ok=True)
#
#     # Process data for each subject
#     for subject_folder in os.listdir(data_folder):
#         subject_dir = os.path.join(data_folder, subject_folder)
#
#         # Check if folder contains EEG data
#         if not any(fname.endswith('.fif'or 'edf' or 'bdf'or 'set' or 'vhdr' or '.csv' ) for fname in os.listdir(subject_dir)):
#             continue
#
#         # Load raw data
#         eeg_file = os.path.join(subject_dir, 'eeg.fif')
#         raw = read_eeg_file(eeg_file)
#         if events==True:
#             # Create events array and event ID dictionary
#             events, event_id = mne.events_from_annotations(raw)
#
#             # Preprocess data
#             plot_preprocessing_steps(raw, events, event_id)
#
#         # Compute forward model if not provided
#         if forward_model is None:
#             fwd = compute_forward_model(raw.info)
#         else:
#             fwd = mne.read_forward_solution(forward_model)
#
#         #Compute noise covariance (trans file)
#
#
#
#
#         # Compute inverse operator
#         inv = compute_inverse_operator(raw, fwd)
#
#         # Compute source estimates
#         stc = compute_source_estimates(raw, inv, normalization_method)
#
#         # Save source estimates
#         subject_results_dir = os.path.join(output_folder, subject_folder)
#         os.makedirs(subject_results_dir, exist_ok=True)
#         stc.save(os.path.join(subject_results_dir, 'source_estimates'))
#
#         print(f"Processed data for {subject_folder}")
