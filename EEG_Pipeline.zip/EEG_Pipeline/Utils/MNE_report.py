



report = mne.Report(title="Src and Alignment")
fig = mne.viz.plot_alignment(
    raw.info,
    src=src,
    eeg=["original", "projected"],
    trans=trans,
    show_axes=True,
    mri_fiducials=True,
    dig="fiducials",
)

report.add_figure(
    fig=fig,
    title="A custom figure",
    caption="generating the MNE Plot…",
    image_format="PNG",
)
report.save("report_custom_figure.html", overwrite=True)
plt.close(fig)