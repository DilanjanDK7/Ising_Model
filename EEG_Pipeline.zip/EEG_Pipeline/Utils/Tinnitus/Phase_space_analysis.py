import os
import numpy as np
import matplotlib.pyplot as plt
import random
from scipy.optimize import leastsq

def load_multiple_npy_files_with_check(base_path, conditions):
    file_types = ['PX', 'X', 'PY', 'Y', 'PZ', 'Z']
    data = {file_type: {condition: {} for condition in conditions} for file_type in file_types}

    for condition in conditions:
        condition_path = os.path.join(base_path, condition)
        subjects = os.listdir(condition_path)
        subject_file_count = {subject: 0 for subject in subjects}

        for subject in subjects:
            for file_type in file_types:
                file_path = os.path.join(condition_path, subject, f'QM_model/files/Average{file_type}.npy')
                if os.path.isfile(file_path):
                    if subject not in data[file_type][condition]:
                        data[file_type][condition][subject] = []
                    data[file_type][condition][subject].append(np.load(file_path))
                    subject_file_count[subject] += 1
                else:
                    print(f"File not found: {file_path}")

        for subject, count in subject_file_count.items():
            if count != len(file_types):
                print(
                    f"Warning: Not all files loaded for {subject} in {condition}. Loaded {count}/{len(file_types)} files.")

    return data


def plot_and_save_phase_space(subject_data, subject, output_dir):
    plots_dir = os.path.join(output_dir, 'Plots', subject)
    os.makedirs(plots_dir, exist_ok=True)

    for dimension in ['X', 'Y', 'Z']:
        plt.figure()
        plt.scatter(subject_data[dimension], subject_data[f'P{dimension}'], label=f'{dimension} vs P{dimension}')
        plt.xlabel(dimension)
        plt.ylabel(f'P{dimension}')
        plt.title(f'Phase Space Plot - {dimension}')
        # plt.legend()
        plt.savefig(os.path.join(plots_dir, f'phase_space_{dimension}.png'))
        plt.close()


def plot_combined_phase_space(loaded_data, n_subjects, output_dir):
    group_analysis_dir = os.path.join(output_dir, 'group_analysis')
    os.makedirs(group_analysis_dir, exist_ok=True)

    colors = {'Controls': 'blue', 'Patients': 'red'}
    plt.figure()

    for condition, color in colors.items():
        subjects = list(loaded_data['X'][condition].keys())
        selected_subjects = random.sample(subjects, min(n_subjects, len(subjects)))

        for subject in selected_subjects:
            subject_data = {file_type: loaded_data[file_type][condition][subject] for file_type in loaded_data}
            for dimension in ['X', 'Y', 'Z']:
                plt.plot(subject_data[dimension], subject_data[f'P{dimension}'], label=f'{condition} - {dimension}',
                         color=color)

    plt.xlabel('Position')
    plt.ylabel('Momentum')
    plt.title('Combined Phase Space Plot')
    # plt.legend()
    plt.savefig(os.path.join(group_analysis_dir, 'combined_phase_space.png'))
    plt.close()


# Circle fitting function
def fit_circle_to_points(x, y):
    x = np.asarray(x)
    y = np.asarray(y)

    # Compute the centroid (mean of x and y coordinates)
    centroid_x = np.mean(x)
    centroid_y = np.mean(y)

    # Calculate the distance of each point from the centroid
    distances = np.sqrt((x - centroid_x)**2 + (y - centroid_y)**2)

    # The radius is the distance to the farthest point
    radius = np.max(distances)

    return (centroid_x, centroid_y), radius





# Function to plot and save individual phase space with circle fit
def plot_and_save_phase_space(subject_data, subject, output_dir):
    plots_dir = os.path.join(output_dir, 'Plots', subject)
    os.makedirs(plots_dir, exist_ok=True)

    for dimension in ['X', 'Y', 'Z']:
        plt.figure()
        x = subject_data[dimension]
        y = subject_data[f'P{dimension}']
        plt.scatter(x, y, label=f'{dimension} vs P{dimension}')

        # Fit and plot circle
        center, radius = fit_circle_to_points(x, y)
        circle = plt.Circle(center, radius, color='r', fill=False)
        plt.gca().add_artist(circle)

        plt.xlabel(dimension)
        plt.ylabel(f'P{dimension}')
        plt.title(f'Phase Space Plot with Circle Fit - {dimension}')
        plt.savefig(os.path.join(plots_dir, f'phase_space_circle_fit_{dimension}.png'))
        plt.close()

# Function to plot combined phase space with circle fit
def plot_combined_phase_space(loaded_data, n_subjects, output_dir):
    group_analysis_dir = os.path.join(output_dir, 'group_analysis')
    os.makedirs(group_analysis_dir, exist_ok=True)

    colors = {'Controls': 'blue', 'Patients': 'red'}
    plt.figure()

    for condition, color in colors.items():
        subjects = list(loaded_data['X'][condition].keys())
        selected_subjects = random.sample(subjects, min(n_subjects, len(subjects)))

        for subject in selected_subjects:
            subject_data = {file_type: loaded_data[file_type][condition][subject] for file_type in loaded_data}
            for dimension in ['X', 'Y', 'Z']:
                x = subject_data[dimension]
                y = subject_data[f'P{dimension}']
                plt.scatter(x, y, label=f'{condition} - {dimension}', color=color)

                # Fit and plot circle
                center, radius = fit_circle_to_points(x, y)
                circle = plt.Circle(center, radius, color='r', fill=False)
                plt.gca().add_artist(circle)

    plt.xlabel('Position')
    plt.ylabel('Momentum')
    plt.title('Combined Phase Space Plot with Circle Fit')
    plt.savefig(os.path.join(group_analysis_dir, 'combined_phase_space_circle_fit.png'))
    plt.close()

# Main function
def main(base_path, conditions, n_subjects):
    loaded_data = load_multiple_npy_files_with_check(base_path, conditions)
    output_dir = '/media/brainlab-qm/QM Run Data 2022/Dilanjan/Outputs/Tinnitus_Conference_analysis/Phase_space'
    os.makedirs(output_dir, exist_ok=True)
    for condition in conditions:
        for subject in loaded_data['X'][condition]:
            subject_data = {file_type: loaded_data[file_type][condition][subject] for file_type in loaded_data}
            plot_and_save_phase_space(subject_data, subject, output_dir)
            print("Running for : ", subject)
    plot_combined_phase_space(loaded_data, n_subjects, output_dir)

# Configuration and execution
conditions = ['Controls', 'Patients']
base_path = '/media/brainlab-qm/QM Run Data 2022/Dilanjan/Outputs/Tinnitus_outputs'
n_subjects = 10

main(base_path, conditions, n_subjects)