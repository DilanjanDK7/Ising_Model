import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os
from scipy.stats import mannwhitneyu
import networkx as nx
import community as community_louvain
from sklearn.decomposition import PCA
from pandas.plotting import parallel_coordinates

def analyze_TPM(file_path, subject, condition, eye_condition):
    # Load the data
    data = pd.read_csv(file_path, delimiter=' ', header=None)
    data.columns = network_names
    data.index = network_names

    # Create output directory for individual analysis
    output_dir = os.path.join(file_path.rsplit('/', 3)[0], 'statistical_analysis')
    os.makedirs(output_dir, exist_ok=True)

    # Summary Statistics
    summary_statistics = data.describe().T
    summary_statistics['median'] = data.median()
    summary_statistics.to_csv(f'{output_dir}/summary_statistics.csv')

    # Stochasticity Check
    row_sums = data.sum(axis=1)
    col_sums = data.sum(axis=0)
    stochasticity_check_rows = row_sums.apply(lambda x: abs(x - 1) < 1e-3)
    stochasticity_check_cols = col_sums.apply(lambda x: abs(x - 1) < 1e-3)
    with open(f'{output_dir}/stochasticity_check.txt', 'w') as file:
        file.write("Row Sums:\n")
        file.write(row_sums.to_string())
        file.write("\nColumn Sums:\n")
        file.write(col_sums.to_string())
        file.write(f"\nStochasticity Check for Rows Passed: {stochasticity_check_rows.all()}")
        file.write(f"\nStochasticity Check for Columns Passed: {stochasticity_check_cols.all()}")

    # Eigenvalue Analysis
    eigenvalues, eigenvectors = np.linalg.eig(data)
    largest_eigenvalue_index = np.argmax(eigenvalues)
    steady_state_distribution = eigenvectors[:, largest_eigenvalue_index]
    steady_state_distribution = steady_state_distribution / steady_state_distribution.sum()
    steady_state_df = pd.DataFrame(steady_state_distribution, index=network_names, columns=['Steady State Probability'])
    steady_state_df['Eigenvalue'] = eigenvalues[largest_eigenvalue_index]
    steady_state_df.to_csv(f'{output_dir}/eigenvalue_analysis.csv')
    plt.bar(network_names, eigenvalues)
    plt.title('Eigenvalues')
    plt.xlabel('Network')
    plt.ylabel('Eigenvalue')
    plt.savefig(f'{output_dir}/eigenvalues.png')
    plt.close()

    # Heatmap Visualization
    plt.figure(figsize=(12, 10))
    sns.heatmap(data, annot=False, cmap="YlGnBu", linewidths=.5)
    plt.title(f'TPM - {condition} - {eye_condition}', fontsize=15)
    plt.xlabel('Target Network', fontsize=13)
    plt.ylabel('Source Network', fontsize=13)
    plt.savefig(f'{output_dir}/heatmap.png')
    plt.close()

    # Network Graph (using NetworkX)
    visualize_network_graph(data, output_dir)

    # Return the data and eigenvalues for group analysis
    return data, eigenvalues

def visualize_network_graph(data, output_dir):
    # Create a Graph from the TPM data
    G = nx.from_numpy_array(data.values)

    # Apply the Louvain method for community detection
    partition = community_louvain.best_partition(G)

    # Create a color map for communities
    cmap = plt.cm.get_cmap('viridis', max(partition.values()) + 1)

    # Draw the nodes, with node color indicating community
    nx.draw_networkx_nodes(G, pos=nx.spring_layout(G), cmap=cmap, node_color=list(partition.values()), node_size=200)

    # Draw the edges, with width indicating weight
    for i, j, weight in G.edges(data='weight'):
        nx.draw_networkx_edges(G, pos=nx.spring_layout(G), edgelist=[(i, j)], width=weight * 5)

    # Draw the node labels (network names)
    nx.draw_networkx_labels(G, pos=nx.spring_layout(G), labels={i: name for i, name in enumerate(network_names)})

    # Save the plot
    plt.title('Network Graph with Communities')
    plt.savefig(f'{output_dir}/network_graph.png')
    plt.close()
def group_analysis(tpms_open, tpms_closed, eigenvalues_open, eigenvalues_closed, condition_path, condition):
    # Create output directory for group analysis
    output_dir_group = os.path.join(condition_path, 'statistical_analysis_group')
    os.makedirs(output_dir_group, exist_ok=True)

    # Calculate mean TPMs for both groups
    mean_tpm_open = np.sum(tpms_open, axis=0) / len(tpms_open)
    mean_tpm_closed = np.sum(tpms_closed, axis=0) / len(tpms_closed)

    # Visualize mean TPMs
    for label, mean_tpm in [('Eyes Open', mean_tpm_open), ('Eyes Closed', mean_tpm_closed)]:
        plt.figure(figsize=(12, 10))
        sns.heatmap(mean_tpm, annot=False, cmap="YlGnBu", linewidths=.5)
        plt.title(f'Mean TPM - {condition} - {label}', fontsize=15)
        plt.xlabel('Target Network', fontsize=13)
        plt.ylabel('Source Network', fontsize=13)
        plt.savefig(f'{output_dir_group}/mean_heatmap_{label}.png')
        plt.close()


    # Difference Heatmaps
    sns.heatmap(mean_tpm_open - mean_tpm_closed, cmap="coolwarm", center=0)
    plt.title('Difference in Mean TPMs (Eyes Open - Eyes Closed)')
    plt.savefig(f'{output_dir_group}/condition_difference_heatmap.png')
    plt.close()

    # Statistical comparison (Mann-Whitney U test)
    u_statistic, p_value = mannwhitneyu(np.array(tpms_open).flatten(), np.array(tpms_closed).flatten())
    with open(f'{output_dir_group}/statistical_comparison.txt', 'w') as file:
        file.write(f"U-Statistic: {u_statistic}\nP-Value: {p_value}")

    # Eigenvalue Comparison
    mean_eigenvalue_open = np.mean(eigenvalues_open, axis=0)
    mean_eigenvalue_closed = np.mean(eigenvalues_closed, axis=0)
    eigenvalue_df = pd.DataFrame({
        'Eyes Open': mean_eigenvalue_open,
        'Eyes Closed': mean_eigenvalue_closed
    })
    eigenvalue_df.to_csv(f'{output_dir_group}/mean_eigenvalues.csv')

# Network names and conditions
network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
conditions = ['Controls', 'Patients']
base_path = '/media/brainlab-qm/QM Run Data 2022/Dilanjan/Outputs/Tinnitus_outputs'

# Iterate through conditions and subjects
for condition in conditions:
    condition_path = os.path.join(base_path, condition)
    subjects = os.listdir(condition_path)

    # Lists to store TPMs and eigenvalues for group analysis
    tpms_open = []
    tpms_closed = []
    eigenvalues_open = []
    eigenvalues_closed = []

    for subject in subjects:
        # Construct file path using subject name
        file_path = os.path.join(condition_path, subject, f'QM_model/network_analysis/TPM_per_source_{subject}.csv')

        # Identify eye condition
        eye_condition = "Eyes Closed" if "EC" in subject else "Eyes Open"

        # Analyze individual TPM
        tpm_data, eigenvalues = analyze_TPM(file_path, subject, condition, eye_condition)
        print("Subject "+subject+" done")
        # Append to corresponding lists for group analysis
        if eye_condition == "Eyes Closed":
            tpms_closed.append(tpm_data)
            eigenvalues_closed.append(eigenvalues)
        else:
            tpms_open.append(tpm_data)
            eigenvalues_open.append(eigenvalues)

    # Conduct group analysis for the condition
    group_analysis(tpms_open, tpms_closed, eigenvalues_open, eigenvalues_closed, condition_path, condition)
