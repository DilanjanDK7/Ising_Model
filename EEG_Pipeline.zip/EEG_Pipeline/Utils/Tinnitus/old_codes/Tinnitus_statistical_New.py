import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os
import logging
from scipy.stats import mannwhitneyu, ttest_ind
import networkx as nx
import community as community_louvain

# Configure logging
logging.basicConfig(filename='../analysis_log.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def load_data(file_path, network_names):
    """Load TPM data and validate"""
    try:
        data = pd.read_csv(file_path, delimiter=' ', header=None)
        if data.shape != (len(network_names), len(network_names)) or (data < 0).any().any() or (data > 1).any().any():
            raise ValueError("Invalid TPM data")
        data.columns = network_names
        data.index = network_names
        return data
        logging.INFO("File loaded "+str(file_path))
    except Exception as e:
        logging.error(f"Error loading data from {file_path}: {str(e)}")
        raise

def create_output_directory(file_path, sub_dir):
    """Create output directory"""
    output_dir = os.path.join(file_path.rsplit('/', 3)[0], sub_dir)
    os.makedirs(output_dir, exist_ok=True)
    return output_dir

def summary_statistics(data, output_dir):
    """Calculate and save summary statistics"""
    summary = data.describe().T
    summary['median'] = data.median()
    summary.to_csv(f'{output_dir}/summary_statistics.csv')

def stochasticity_check(data, output_dir):
    """Check stochasticity and save results"""
    row_sums = data.sum(axis=1)
    stochasticity_check_rows = row_sums.apply(lambda x: abs(x - 1) < 1e-3)
    with open(f'{output_dir}/stochasticity_check.txt', 'w') as file:
        file.write("Row Sums:\n")
        file.write(row_sums.to_string())
        file.write(f"\nStochasticity Check for Rows Passed: {stochasticity_check_rows.all()}")

def eigenvalue_analysis(data, network_names, output_dir):
    """Perform eigenvalue analysis and save results"""
    eigenvalues, eigenvectors = np.linalg.eig(data)
    largest_eigenvalue_index = np.argmax(eigenvalues.real)
    steady_state_distribution = eigenvectors[:, largest_eigenvalue_index]
    steady_state_distribution = steady_state_distribution / steady_state_distribution.sum()
    steady_state_df = pd.DataFrame(steady_state_distribution.real, index=network_names, columns=['Steady State Probability'])
    steady_state_df['Eigenvalue'] = eigenvalues[largest_eigenvalue_index].real
    steady_state_df.to_csv(f'{output_dir}/eigenvalue_analysis.csv')
    plt.bar(network_names, eigenvalues.real)
    plt.title('Eigenvalues')
    plt.xlabel('Network')
    plt.ylabel('Eigenvalue')
    plt.savefig(f'{output_dir}/eigenvalues.png')
    plt.close()

def heatmap_visualization(data, title, output_dir):
    """Create and save heatmap visualization"""
    plt.figure(figsize=(12, 10))
    sns.heatmap(data, annot=False, cmap="YlGnBu", linewidths=.5)
    plt.title(title, fontsize=15)
    plt.xlabel('Target Network', fontsize=13)
    plt.ylabel('Source Network', fontsize=13)
    plt.savefig(f'{output_dir}/heatmap.png')
    plt.close()

def visualize_network_graph(data, network_names, output_dir):
    """Create and save network graph visualization"""
    G = nx.from_numpy_array(data.values)
    layout = nx.spring_layout(G)
    partition = community_louvain.best_partition(G)
    cmap = plt.cm.get_cmap('viridis', max(partition.values()) + 1)
    nx.draw_networkx_nodes(G, pos=layout, cmap=cmap, node_color=list(partition.values()), node_size=200)
    for i, j, weight in G.edges(data='weight'):
        nx.draw_networkx_edges(G, pos=layout, edgelist=[(i, j)], width=weight * 5)
    nx.draw_networkx_labels(G, pos=layout, labels={i: name for i, name in enumerate(network_names)})
    plt.title('Network Graph with Communities')
    plt.savefig(f'{output_dir}/network_graph.png')
    plt.close()

def analyze_TPM(file_path, network_names, subject, condition, eye_condition):
    """Analyze individual TPM, including summary statistics, stochasticity check, eigenvalue analysis, and visualizations"""
    data = load_data(file_path, network_names)
    output_dir = create_output_directory(file_path, 'statistical_analysis')
    summary_statistics(data, output_dir)
    stochasticity_check(data, output_dir)
    eigenvalue_analysis(data, network_names, output_dir)
    heatmap_visualization(data, f'TPM - {condition} - {eye_condition}', output_dir)
    visualize_network_graph(data, network_names, output_dir)
    return data, eigenvalue_analysis(data, network_names, output_dir)

def group_analysis(tpms_open, tpms_closed, network_names, condition_path, condition):
    """Group analysis including mean TPMs, difference heatmaps, statistical comparison, and eigenvalue comparison"""
    output_dir_group = create_output_directory(condition_path, 'statistical_analysis_group')
    mean_tpm_open = np.mean(tpms_open, axis=0)
    mean_tpm_closed = np.mean(tpms_closed, axis=0)
    heatmap_visualization(mean_tpm_open, f'Mean TPM - {condition} - Eyes Open', output_dir_group)
    heatmap_visualization(mean_tpm_closed, f'Mean TPM - {condition} - Eyes Closed', output_dir_group)
    sns.heatmap(mean_tpm_open - mean_tpm_closed, cmap="coolwarm", center=0)
    plt.title('Difference in Mean TPMs (Eyes Open - Eyes Closed)')
    plt.savefig(f'{output_dir_group}/condition_difference_heatmap.png')
    plt.close()
    u_statistic, p_value = mannwhitneyu(np.array(tpms_open).flatten(), np.array(tpms_closed).flatten())
    with open(f'{output_dir_group}/statistical_comparison.txt', 'w') as file:
        file.write(f"U-Statistic: {u_statistic}\nP-Value: {p_value}")

def statistical_comparisons(tpms_controls, tpms_patients, output_dir_group):
    """Perform statistical comparisons between controls and patients, including t-tests"""
    try:
        t_statistic, p_value_ttest = ttest_ind(np.array(tpms_controls).flatten(), np.array(tpms_patients).flatten())
        with open(f'{output_dir_group}/statistical_comparisons.txt', 'w') as file:
            file.write(f"T-Test: T-Statistic: {t_statistic}, P-Value: {p_value_ttest}\n")
        logging.info(f"Statistical comparisons (t-test) between controls and patients completed.")
    except Exception as e:
        logging.error(f"Error in statistical comparisons between controls and patients: {str(e)}")

def create_statistical_comparisons_directory(base_path):
    """Create a directory for saving statistical comparisons between controls and patients"""
    output_dir_comparison = os.path.join(base_path, 'Tinnitus_outputs', 'statistical_comparisons')
    os.makedirs(output_dir_comparison , exist_ok=True)
    return output_dir_comparison
def bonferroni_correction(tpms_group1, tpms_group2, network_names, output_dir):
    """Apply Bonferroni correction for multiple comparisons between two groups of TPMs"""
    flat_group1 = np.array(tpms_group1).flatten()
    flat_group2 = np.array(tpms_group2).flatten()
    _, p_value_ttest = ttest_ind(flat_group1, flat_group2)
    corrected_p_value = min(p_value_ttest * len(flat_group1), 1)
    corrected_p_value_tpm = np.full_like(tpms_group1[0], corrected_p_value)
    corrected_p_value_df = pd.DataFrame(corrected_p_value_tpm, index=network_names, columns=network_names)
    corrected_p_value_df.to_csv(f'{output_dir}/bonferroni_corrected_p_values.csv')
    plt.figure(figsize=(12, 10))
    sns.heatmap(corrected_p_value_tpm, annot=True, cmap="YlGnBu", linewidths=.5)
    plt.title('Bonferroni Corrected P-Values TPM')
    plt.xlabel('Target Network')
    plt.ylabel('Source Network')
    plt.savefig(f'{output_dir}/bonferroni_corrected_heatmap.png')
    plt.close()
    return corrected_p_value_tpm


def between_condition_analysis(tpms_controls, tpms_patients, network_names, base_path):
    """Perform analysis between controls and patients"""
    output_dir_group = create_statistical_comparisons_directory(base_path)

    # Apply Bonferroni correction
    bonferroni_correction(tpms_controls, tpms_patients, network_names, output_dir_group)


def main(base_path, network_names, conditions):
    """Main function to iterate through conditions and subjects for analysis"""
    try:
        tpms_controls, tpms_patients = [], []
        for condition in conditions:
            condition_path = os.path.join(base_path, condition)
            subjects = os.listdir(condition_path)
            tpms_open, tpms_closed = [], []
            for subject in subjects:
                # Skip the 'statistical_analysis_group' folder
                if subject == 'statistical_analysis_group':
                    continue
                print("subject "+subject+ " running")
                file_path = os.path.join(condition_path, subject, f'QM_model/network_analysis/TPM_per_source_{subject}.csv')
                eye_condition = "Eyes Closed" if "EC" in subject else "Eyes Open"
                tpm_data, _ = analyze_TPM(file_path, network_names, subject, condition, eye_condition)
                (tpms_closed if eye_condition == "Eyes Closed" else tpms_open).append(tpm_data)
            group_analysis(tpms_open, tpms_closed, network_names, condition_path, condition)
            (tpms_controls if condition == 'Controls' else tpms_patients).extend(tpms_open + tpms_closed)
            # Additional statistical analysis between controls and patients
            output_dir_group = create_output_directory(base_path, 'statistical_analysis_group_controls_vs_patients')
            statistical_comparisons(tpms_controls, tpms_patients, output_dir_group)
            between_condition_analysis(tpms_controls, tpms_patients, network_names, base_path)

    except Exception as e:
        logging.error(f"Error in main analysis: {str(e)}")


# Configuration
network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
conditions = ['Controls', 'Patients']
base_path = '/media/brainlab-qm/QM Run Data 2022/Dilanjan/Outputs/Tinnitus_outputs'

# Run analysis
main(base_path, network_names, conditions)