import mne
import numpy as np
import pandas as pd

def tinnitus_info(loc_file,sampling_freq=128):
    b=mne.channels.read_custom_montage(loc_file, head_size=0.095, coord_frame='mri')
    ch_names = b._get_dig_names()
    ch_types = ["eeg"] * len(ch_names)
    info = mne.create_info(ch_names, ch_types=ch_types, sfreq=sampling_freq)
    info.set_montage("standard_1020")
    montage =info.get_montage()
    # fig3 =montage.plot()
    # fig3.savefig(fname='/home/brainlab-qm/EEG_test/fig/fig3.png')
    return info

def read_files(file_name,info):
    data=np.loadtxt(file_name)*(1/1000000)
    montage = info.get_montage()
    no_of_channels=len(montage.ch_names)
    if no_of_channels==data.shape[0]:
        data =data
    elif no_of_channels==data.shape[1]:
        data =data.transpose()
    else:
        raise("Error in file .Channels do not match")
    raw = mne.io.RawArray(data, info)
    raw.filter(l_freq=2,h_freq=44)
    return raw
