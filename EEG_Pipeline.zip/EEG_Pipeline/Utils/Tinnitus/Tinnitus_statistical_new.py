import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os
import logging
from scipy.stats import ttest_ind
from scipy.stats import mannwhitneyu, ttest_ind
from statsmodels.stats.multitest import multipletests
import networkx as nx
import community as community_louvain

# Configure logging
logging.basicConfig(filename='analysis_log.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def load_data(file_path, network_names):
    """Load TPM data and validate"""
    try:
        data = pd.read_csv(file_path, delimiter=' ', header=None)
        if data.shape != (len(network_names), len(network_names)) or (data < 0).any().any() or (data > 1).any().any():
            raise ValueError("Invalid TPM data")
        data.columns = network_names
        data.index = network_names
        logging.info(f"File loaded: {file_path}")
        return data
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        raise
    except ValueError as e:
        logging.error(f"Error loading data from {file_path}: {str(e)}")
        raise


def create_output_directory(file_path, sub_dir, condition, subject):
    """Create output directory preserving folder structure"""
    output_dir = os.path.join(file_path.rsplit('/', 1)[0], 'statistical_analysis', condition, subject, sub_dir)
    os.makedirs(output_dir, exist_ok=True)
    return output_dir


def summary_statistics(data, output_dir):
    """Calculate and save summary statistics"""
    summary = data.describe().T
    summary['median'] = data.median()
    summary.to_csv(f'{output_dir}/summary_statistics.csv')


def stochasticity_check(data, output_dir):
    """Check stochasticity and save results"""
    row_sums = data.sum(axis=1)
    stochasticity_check_rows = row_sums.apply(lambda x: abs(x - 1) < 1e-3)
    with open(f'{output_dir}/stochasticity_check.txt', 'w') as file:
        file.write("Row Sums:\n")
        file.write(row_sums.to_string())
        file.write(f"\nStochasticity Check for Rows Passed: {stochasticity_check_rows.all()}")


def eigenvalue_analysis(data, network_names, output_dir):
    """Perform eigenvalue analysis and save results"""
    eigenvalues, eigenvectors = np.linalg.eig(data)
    largest_eigenvalue_index = np.argmax(eigenvalues.real)
    if eigenvalues[largest_eigenvalue_index] == 0:
        logging.warning("Largest eigenvalue is zero; skipping eigenvalue analysis.")
        return None
    steady_state_distribution = eigenvectors[:, largest_eigenvalue_index]
    steady_state_distribution = steady_state_distribution / steady_state_distribution.sum()
    steady_state_df = pd.DataFrame(steady_state_distribution.real, index=network_names,
                                   columns=['Steady State Probability'])
    steady_state_df['Eigenvalue'] = eigenvalues[largest_eigenvalue_index].real
    steady_state_df.to_csv(f'{output_dir}/eigenvalue_analysis.csv')
    plt.bar(network_names, eigenvalues.real)
    plt.title('Eigenvalues')
    plt.xlabel('Network')
    plt.ylabel('Eigenvalue')
    plt.savefig(f'{output_dir}/eigenvalues.png')
    plt.close()


def heatmap_visualization(data, title, output_dir):
    """Create and save heatmap visualization"""
    plt.figure(figsize=(12, 10))
    sns.heatmap(data, annot=False, cmap="viridis", linewidths=.5)
    plt.title(title, fontsize=15)
    plt.xlabel('Target Network', fontsize=13)
    plt.ylabel('Source Network', fontsize=13)
    plt.savefig(f'{output_dir}/heatmap.png')
    plt.close()


def visualize_network_graph(data, network_names, output_dir):
    """Create and save network graph visualization"""
    G = nx.from_numpy_array(data.values)
    layout = nx.spring_layout(G)
    partition = community_louvain.best_partition(G)
    cmap = plt.cm.get_cmap('viridis', max(partition.values()) + 1)
    nx.draw_networkx_nodes(G, pos=layout, cmap=cmap, node_color=list(partition.values()), node_size=200)
    for i, j, weight in G.edges(data='weight'):
        nx.draw_networkx_edges(G, pos=layout, edgelist=[(i, j)], width=weight * 5)
    nx.draw_networkx_labels(G, pos=layout, labels={i: name for i, name in enumerate(network_names)})
    plt.title('Network Graph with Communities')
    plt.savefig(f'{output_dir}/network_graph.png')
    plt.close()


def analyze_TPM(file_path, network_names, subject, condition, eye_condition, base_path):
    """Analyze individual TPM, including summary statistics, stochasticity check, eigenvalue analysis, and visualizations"""
    data = load_data(file_path, network_names)
    output_dir = create_output_directory(base_path, 'individual_analysis', condition, subject)
    summary_statistics(data, output_dir)
    stochasticity_check(data, output_dir)
    eigenvalue_analysis(data, network_names, output_dir)
    heatmap_visualization(data, f'TPM - {condition} - {eye_condition}', output_dir)
    visualize_network_graph(data, network_names, output_dir)
    return data, eigenvalue_analysis(data, network_names, output_dir)


def bonferroni_correction(p_values_matrix, network_names, output_dir, alpha=0.05):
    # Apply Bonferroni correction
    corrected_p_values = multipletests(p_values_matrix.flatten(), method='bonferroni')[1]
    # Reshape the corrected p-values back to the original matrix shape
    corrected_p_values_matrix = corrected_p_values.reshape(12, 12)
    return corrected_p_values_matrix


def benjamini_hochberg_correction(p_values, output_dir, alpha=0.05):
    """Apply Benjamini-Hochberg correction for multiple comparisons"""
    corrected_p_values = multipletests(p_values.flatten(), method='fdr_bh')[1]
    corrected_p_values_tpm = corrected_p_values.reshape(len(network_names), len(network_names))
    return corrected_p_values_tpm


def create_statistical_comparisons_directory(base_path):
    output_dir_comparison = os.path.join(base_path, 'statistical_analysis', 'statistical_comparisons')
    os.makedirs(output_dir_comparison, exist_ok=True)
    return output_dir_comparison


def calculate_p_values_and_t_statistics(tpms_controls, tpms_patients):
    controls_array = np.array(tpms_controls)
    patients_array = np.array(tpms_patients)
    p_values_matrix = np.empty((12, 12))
    t_statistics_matrix = np.empty((12, 12))
    for i in range(12):
        for j in range(12):
            control_values = controls_array[:, i, j]
            patient_values = patients_array[:, i, j]
            t_statistic, p_value = ttest_ind(control_values, patient_values, equal_var=False)
            p_values_matrix[i, j] = p_value
            t_statistics_matrix[i, j] = t_statistic
    return p_values_matrix, t_statistics_matrix


def calculate_mean_and_statistical_analysis(tpms_controls, tpms_patients, network_names, output_dir_group):
    mean_tpm_controls = np.mean(tpms_controls, axis=0)
    mean_tpm_patients = np.mean(tpms_patients, axis=0)
    heatmap_visualization(mean_tpm_controls, 'Mean TPM - Controls', output_dir_group)
    heatmap_visualization(mean_tpm_patients, 'Mean TPM - Patients', output_dir_group)

    p_values_matrix, t_statistics_matrix = calculate_p_values_and_t_statistics(tpms_controls, tpms_patients)

    # Bonferroni correction
    corrected_p_values_matrix = bonferroni_correction(p_values_matrix, network_names, output_dir_group)

    # Benjamini-Hochberg correction
    benjamini_hochberg_correction(p_values_matrix, output_dir_group)

    # Threshold for significance (e.g., 0.05)
    alpha = 0.05

    # Create a mask for statistically significant cells
    significant_mask = corrected_p_values_matrix < alpha

    # Plotting the heatmap of T-statistics with the mask
    plt.figure(figsize=(12, 10))
    sns.heatmap(t_statistics_matrix, annot=True, cmap="coolwarm", linewidths=.5,
                xticklabels=network_names, yticklabels=network_names, mask=~significant_mask)
    plt.title('T-Statistics with Significant Cells Highlighted')
    plt.xlabel('Target Network')
    plt.ylabel('Source Network')
    plt.savefig(f'{output_dir_group}/t_statistics_with_significance.png')
    plt.close()


def group_analysis(tpms_open, tpms_closed, network_names, condition_path, condition, base_path):
    output_dir_group = create_output_directory(base_path, 'group_analysis', condition, '')
    mean_tpm_open = np.mean(tpms_open, axis=0)
    mean_tpm_closed = np.mean(tpms_closed, axis=0)
    heatmap_visualization(mean_tpm_open, f'Mean TPM - {condition} - Eyes Open', output_dir_group)
    heatmap_visualization(mean_tpm_closed, f'Mean TPM - {condition} - Eyes Closed', output_dir_group)
    sns.heatmap(mean_tpm_open - mean_tpm_closed, cmap="coolwarm", center=0)
    plt.title('Difference in Mean TPMs (Eyes Open - Eyes Closed)')
    plt.savefig(f'{output_dir_group}/condition_difference_heatmap.png')
    plt.close()
    u_statistic, p_value = mannwhitneyu(np.array(tpms_open).flatten(), np.array(tpms_closed).flatten())
    with open(f'{output_dir_group}/statistical_comparison.txt', 'w') as file:
        file.write(f"U-Statistic: {u_statistic}\nP-Value: {p_value}")

# (Same code as before...)

def main(base_path, network_names, conditions):
    try:
        tpms_controls, tpms_patients = [], []
        for condition in conditions:
            condition_path = os.path.join(base_path, condition)
            subjects = os.listdir(condition_path)
            tpms_open, tpms_closed = [], []
            for subject in subjects:
        # (Same code as before...)

        output_dir_group = create_statistical_comparisons_directory(base_path)
        calculate_mean_and_statistical_analysis(tpms_controls, tpms_patients, network_names, output_dir_group)
    except Exception as e:
        logging.error(f"Error in main analysis: {str(e)}")


# Configuration
network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
                 'smhand', 'smmouth', 'ventral', 'frontoparietal']
conditions = ['Controls', 'Patients']
base_path = '/path/to/your/directory'

# Run analysis
main(base_path, network_names, conditions)
