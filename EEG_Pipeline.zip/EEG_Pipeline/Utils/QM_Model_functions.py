import finufft
import scipy
from scipy.signal import hilbert
import sys
import os
import logging
import numpy as np
import shutil
from numpy.lib.format import read_magic, read_array_header_1_0



#######  Basic Functions ##############

def mni_to_meters(x,y,z):
    x=x/100
    y=y/100
    z=z/100
    return x,y,z

def extract_data(stc):
    data = stc.lh_data
    rh_data = stc.rh_data
    data = np.append(data, rh_data,axis=0)
    del rh_data
    return data

def zip_x_y(x,y):
    assert len(x) == len(y)
    return np.stack((x,y))

def zip_x_y_z(x,y,z):
    assert len(x)==len(y)==len(z)
    return np.stack((x,y,z))

def file_exists(filename):
    import os
    exists = os.path.isfile(filename)
    if exists:
        return True
    else:
        return False

def makedir2(path):
    import os
    if not os.path.exists(path):
        os.mkdir(path)
        return True
    return True

def load_matrix(filepath,dtype=np.float64):
    extension = filepath.split('.')[-1]
    if str(extension) == 'csv':
        return np.genfromtxt(filepath,delimiter = ',', dtype=dtype)
    elif str(extension) == 'npy':
        return np.load(filepath)
    elif str(extension) == 'mat':
        return scipy.io.loadmat(filepath)
    elif str(extension) == 'npz':
        return np.load(filepath)

def save_file(data,path,name):

    if hasattr(data, '__len__') and (not isinstance(data, str)):
        data = np.asarray(data)


    default_delimiter = ','
    format = '%1.5f'

    if len(data.shape) <= 2:
        file = path + str(name) + '.csv'

        if not file_exists(file):
            np.savetxt(file, data, delimiter=default_delimiter)
    else:
        file = path + str(name) + '.npy'
        if not file_exists(file):
            np.save(file,[data])

def delete_folder(path):
    """
    Deletes a folder and all of its contents.

    Args:
        path (str): The path of the folder to delete.
    """
    try:
        # Remove the folder and all of its contents
        shutil.rmtree(path)
        print(f"Successfully deleted folder at {path}")
    except OSError as e:
        print(f"Error: {path} : {e.strerror}")

    return logging.info("Folder Deleted "+str(path))
#######  Add function to check shape of matrix and maintain the
# time and no of sources properly within code

######


######### Physics Functions ############

###### Position Space #######
def hilberto(data,sources,time_points):
    assert len(data.shape) == 2  # cheking dimentionality
    if (data.shape[0]==sources and data.shape[1]==time_points):
        """ The Hilber transform will be taken along the time_source
        Hence the input data should be (sources,time_points)
        and hilbert will be taken along axis=1 (time_points)
        """
        return hilbert(data, axis=1).astype("complex64")
    else:
        logging.info("Please check Data shape. the array should be (Sources,Time_points)")
        sys.exit("Please check Data shape. the array should be (Sources,Time_points)")

def process_eeg_data2(data,sources,time_points):


    hilbertTransData = hilberto(data,sources,time_points)
    amplitude = np.abs(hilbertTransData).T
    """ The normalisation should be done along the sources ,Hence make sure the data is in the right direction
    """
    logging.info("Hilbert Transform done(within func)")
    ampMag = np.sqrt(np.sum((amplitude * amplitude).T, axis=0))
    normAmp = (np.asarray(amplitude.T) / np.asarray(ampMag)).T
    del ampMag,amplitude
    probability = normAmp * normAmp
    del normAmp
    return probability, hilbertTransData

def process_eeg_data(data,sources,time_points):

    hilbertTransData = hilberto(data,sources,time_points)
    amplitude = np.abs(hilbertTransData).T
    phase = np.unwrap(np.angle(hilbertTransData)).T
    """ The normalisation should be done along the sources ,Hence make sure the data is in the right direction
    """
    ampMag = np.sqrt(np.sum((amplitude * amplitude).T, axis=0))
    normAmp = (np.asarray(amplitude.T) / np.asarray(ampMag)).T
    del ampMag,amplitude
    probability = normAmp * normAmp
    del hilbertTransData
    return phase, normAmp, probability

####### Momentum space ######

def calc_k_space_2D(x,y,FOV_Red_Fac=1,Increment_Increase=0,fovx=0.162,fovy=0.200,delx=0.005,dely=0.005):
    '''
    Coordinates should be given in the MNI format for the calculations in m (Meters)
    The K- space is calculated using this function. Please make sure all the entered values are in mm.The function will
    automatically convert to m and perform the calculations
    for the field of view we would use the default size of the brain of model ICBM 152 which will stay the same
    irrespective of montage
    :param fovx: field of view of x ie: total spatial extent of x-space
    :param fovy: Field of view of y ie: total spatial extent of y -space
    no_of_points: The num of fourier points used
    :param x: input the x-position coords
    :param y: input the y-position coords
    :param Increment_Increase: set value to increase the increment size in both axis at the same time
    :return: returns the 3D-matrix containing the points of the k space (kx,ky) respectively
    '''
    # arr=np.array([x,y])
    # min_arr=np.zeros(2,dtype=float)
    # # for i in range(len(arr)):
    # #     xsort=np.sort(arr[i])
    # #     diff = np.diff(xsort)
    # #     sortdiff = np.sort(diff)
    # #     sortdiff = np.delete(sortdiff, np.where(sortdiff == 0))
    # #     min_arr[i]=np.min(sortdiff)

    delpx=1/fovx
    delpy=1/fovy
    fovpx =1/(delx*FOV_Red_Fac)
    fovpy=1/(dely*FOV_Red_Fac)


    #building the K space
    kx = np.arange(-fovpx / 2, fovpx / 2, (delpx+Increment_Increase))
    ky = np.arange(-fovpy / 2, fovpy / 2, (delpy+Increment_Increase))
    px= np.repeat(kx,len(ky))
    py = np.tile(ky,len(kx))

    return px,py,len(kx),len(ky)

def calc_k_space_3D(x,y,z,FOV_Red_Fac=1,Increment_Increase=0,fovx=0.162,fovy=0.200,fovz=0.170,delx=0.005,dely=0.005,delz=0.005):
    '''
    Coordinates should be given in the MNI format for the calculations in m (Meters)
    The K- space is calculated using this function. Please make sure all the entered values are in mm.The function will
    automatically convert to m and perform the calculations
    for the field of view we would use the default size of the brain of model ICBM 152 which will stay the same
    irrespective of montage
    :param fovx: field of view of x ie: total spatial extent of x-space
    :param fovy: Field of view of y ie: total spatial extent of y -space
    no_of_points: The num of fourier points used
    :param x: input the x-position coords
    :param y: input the y-position coords
    :param Increment_Increase: set value to increase the increment size in both axis at the same time
    :return: returns the 3D-matrix containing the points of the k space (kx,ky) respectively
    '''
    # arr=np.array([x,y])
    # min_arr=np.zeros(2,dtype=float)
    # # for i in range(len(arr)):
    # #     xsort=np.sort(arr[i])
    # #     diff = np.diff(xsort)
    # #     sortdiff = np.sort(diff)
    # #     sortdiff = np.delete(sortdiff, np.where(sortdiff == 0))
    # #     min_arr[i]=np.min(sortdiff)

    delpx=1/fovx
    delpy=1/fovy
    delpz = 1 / fovz
    fovpx =1/(delx*FOV_Red_Fac)
    fovpy=1/(dely*FOV_Red_Fac)
    fovpz = 1 / (delz * FOV_Red_Fac)

    #building the K space
    kx = np.arange(-fovpx / 2, fovpx / 2, (delpx+Increment_Increase))
    ky = np.arange(-fovpy / 2, fovpy / 2, (delpy+Increment_Increase))
    kz = np.arange(-fovpz / 2, fovpz / 2, (delpz + Increment_Increase))
    kx_mid=np.tile(kx, len(ky))
    ky_mid=np.repeat(ky,len(kx))
    px=np.tile(kx_mid,len(kz))
    py=np.tile(ky_mid,len(kz))
    pz=np.repeat(kz,len(kx)*len(ky))
    logging.info(("K- Space Calculated: kx ",len(px),"ky ",len(py),"kz ",len(pz),"In Kx,ky and kz of",len(kx),len(ky),len(kz)))
    return px,py,pz,len(kx),len(ky),len(kz)

def norm_mom_prob(momenta_wavefun,sources,time_points):

    # if momenta_wavefun.shape[0] > momenta_wavefun.shape[1]:
    #     momenta_wavefun = momenta_wavefun.T
    if ((momenta_wavefun.shape[1] == sources) and (momenta_wavefun.shape[0] == time_points)): # Modified for source
        momenta_wavefun = momenta_wavefun.T
    elif ((momenta_wavefun.shape[0] == sources) and (momenta_wavefun.shape[1] == time_points)):
        momenta_wavefun=momenta_wavefun
    else:
        logging.error("Please check Data shape. the array should be (Sources,Time_points)")
        logging.error("The shape of the data is ",str(momenta_wavefun.shape))
        sys.exit("Please check Data shape. the array should be (Sources,Time_points)")
    amplitude = np.abs(momenta_wavefun).T
    phase = np.unwrap(np.angle(momenta_wavefun)).T
    ampMag = np.sqrt(np.sum((amplitude * amplitude).T, axis=0))
    """ The normalisation should be done along the sources ,Hence make sure the data is in the right direction
    """
    normAmp = (np.asarray(amplitude.T) / np.asarray(ampMag)).T
    probability = normAmp * normAmp
    del ampMag, amplitude, momenta_wavefun
    logging.info("Calculated nomalized momentum probability")
    return phase, normAmp, probability

def calc_ks(data,mom_wavefun,x,y,px_vals,py_vals):
    phase, amp, probability = process_eeg_data(data)
    psi = amp * np.exp(1j * phase)
    momentum_wavefun = mom_wavefun
    phaseP, ampP, momentum_prob = norm_mom_prob(momentum_wavefun)
    # filepathMom2 = save_path
    x=x
    y=y
    xAvg = probability @ x                  # check and Recheck this code *********
    yAvg = probability @ y
    xSqrAvg = probability @ (x * x)
    ySqrAvg = probability @ (y * y)
    dx = np.sqrt(xSqrAvg - (xAvg * xAvg))
    dy = np.sqrt(ySqrAvg - (yAvg * yAvg))
    m = 1
    pxAvg= np.sum(momentum_prob*px_vals,axis =1)            # check and Recheck this code *********
    pyAvg =np.sum(momentum_prob*py_vals,axis =1)
    pxsqrAvg=np.sum(momentum_prob*np.square(px_vals),axis =1)
    pyaqrAvg=np.sum(momentum_prob*np.square(py_vals),axis =1)
    dpx = m * np.sqrt(pxsqrAvg- (pxAvg * pxAvg))
    dpy = m * np.sqrt(pyaqrAvg- (pyAvg * pyAvg))

    uncertainty_x = dpx * dx
    uncertainty_y = dpy * dy
    return uncertainty_x,uncertainty_y

def momenta_prob(momentum_wavefunction):

    pAmp = np.abs(momentum_wavefunction)
    pPhase = np.unwrap(np.angle(momentum_wavefunction))
    ampMag = np.sqrt(np.sum((pAmp * pAmp).T, axis=0))
    normpAmp = (np.asarray(pAmp.T) / np.asarray(ampMag)).T
    del pAmp,ampMag
    momentum_prob = normpAmp * normpAmp
    return pPhase, normpAmp,
"""
def segmenting_file(data,no_of_parts):
    
    return files

def concatanate_files(files,no_of_parts):
    for i in range(no_of_parts):
        o    
    retun output
"""
def momentum_wavefunc(pos_wavefunc,norm='ortho',axis=1):
    momentum_wavefunction = np.fft.fft(pos_wavefunc,norm=norm,axis=axis)
    return momentum_wavefunction

def get_fourier_finuftt_large(x,y,z,px_vals,py_vals,pz_vals,file_path_wavefun,time_points,sources,fourier_space_length,output_folder,delete_temp=True):
    overwrite=True
    Save=True
    # Define the chunk size
    no_of_chunks =20
    if (time_points>10000):
        new_time_points=int(time_points/no_of_chunks)
        chunk_size=(new_time_points,sources)

    # Create temporary folder to hold calculations

    names=np.empty(no_of_chunks,dtype=object)
    # Open the memory-mapped file for reading
    data = np.load(file_path_wavefun, mmap_mode='r').transpose()
    shape=data.shape
    logging.info(" Position wavefun loaded using memmap with shape "+str(shape))
    # Loop over the chunks
    save_path = os.path.join(output_folder, "temporary folder/")
    makedir2(save_path)
    for i in range(no_of_chunks):

        # Load the chunk into memory
        time_block=()
        chunk = data[new_time_points*(i):new_time_points*(i+1),:]
        logging.info("computing fourier transform for part"+str(i))
        # Perform the computation on the chunk
        filename = save_path + f'results_{i}.npy'
        if not file_exists(filename):
            ft = finufft.nufft3d3(x=x, y=y, z=z, c=chunk.astype('complex128'), isign=-1, s=px_vals,t=py_vals,u=pz_vals, eps=10 ** -4)
            # Save the results to a file
            np.save(filename, ft.astype("complex64"))
            logging.info("file saved in "+ str(filename))
            del ft
            logging.info("deleted temp file ft")
        else:
            logging.info("file"+filename+" loaded")
        # Add the filename to the results array
        names[i] = filename
    logging.info("computed for all files parts")
    pxAvg_tot=np.zeros(time_points)
    pyAvg_tot=np.zeros(time_points)
    pzAvg_tot=np.zeros(time_points)
    for i in range(no_of_chunks):
        chunk = np.load(names[i])
        phaseP, ampP, momentum_prob = norm_mom_prob(chunk, sources=44880, time_points=chunk.shape[0])
        del phaseP,ampP
        # save_file(momentum_prob, save_path, 'Momentum_Probability.csv')
        logging.info(f"Momentum Probability Calculated for chunk {i}")
        logging.info("Calculating Values with momentum probability")
        m = 1
        pxAvg = np.sum(momentum_prob * px_vals, axis=1)  # check and Recheck this code *********
        pyAvg = np.sum(momentum_prob * py_vals, axis=1)
        pzAvg = np.sum(momentum_prob * pz_vals, axis=1)

        pxsqrAvg = np.sum(momentum_prob * np.square(px_vals), axis=1)
        pyaqrAvg = np.sum(momentum_prob * np.square(py_vals), axis=1)
        pzaqrAvg = np.sum(momentum_prob * np.square(pz_vals), axis=1)
        dpx = m * np.sqrt(pxsqrAvg - (pxAvg * pxAvg))
        dpy = m * np.sqrt(pyaqrAvg - (pyAvg * pyAvg))
        dpz = m * np.sqrt(pzaqrAvg - (pzAvg * pzAvg))
        times=pxAvg.shape[0]
        pxAvg_tot[times*i:(i+1)*times]=pxAvg
        pyAvg_tot[times*i:(i+1)*times]=pyAvg
        pzAvg_tot[times*i:(i+1)*times]=pzAvg
    if (overwrite or Save):
        files_path = os.path.join(output_folder, "files/")
        makedir2(files_path)
        logging.info("saving files in" + str(files_path))
        save_np(files_path, pxAvg_tot, 'AveragePX')
        save_np(files_path, pyAvg_tot, 'AveragePY')
        save_np(files_path, pzAvg_tot, 'AveragePZ')
        save_np(files_path, px_vals, 'px_vals')
        save_np(files_path, py_vals, 'py_vals')
        save_np(files_path, pz_vals, 'pz_vals')
        logging.info("files saved in"+str(files_path))
    del data,chunk
    if delete_temp:
        delete_folder(save_path)
        logging.info("Temporary folder deleted")
    return None
def get_data_information(stc):
    sources= stc.data.shape[0]
    time_points =stc.data.shape[1]
    return sources,time_points
######### QM Pipeline ########

# def assert_directions_matrix(data,sources,time_points):
#     assert len(data.shape) == 2
#     return None
def save_np(save_path,variable,name):
    filename=os.path.join(save_path, str(name) + '.npy')
    np.save(filename,variable)
    return logging.info(str(name)+"file saved")
def QM_model_run(data,x,y,z,px_vals,py_vals,pz_vals,save_path,time_points,No_sources,overwrite=False,Save=True,clear_intermediate=True):
    if (not(file_exists(save_path + 'momentum_wavefun2.npy'))or overwrite):
        if not file_exists(save_path + 'Hilbert_trans_data.npy'):
            logging.info("Performing Hilbert Transform and extracting position Probability")
            probability, wavefun = process_eeg_data2(data,sources=No_sources,time_points=time_points)
            logging.info("Hilbert Transform Done")
            logging.info("saving files")
            np.save(save_path + 'Probability_matrix.npy', probability)
            np.save(save_path + 'Hilbert_trans_data.npy', wavefun.astype("complex64"))
            logging.info("Position probability Calculated and saved")
            ####### Calculating Position values ########
            logging.info("calculating files for position probability ")
            xAvg = probability @ x  # check and Recheck this code *********
            yAvg = probability @ y
            zAvg = probability @ z
            logging.info("Average position values calculated")
            xSqrAvg = probability @ (x * x)
            ySqrAvg = probability @ (y * y)
            zSqrAvg = probability @ (z * z)
            logging.info("Average Squared values calculated")
            dx = np.sqrt(xSqrAvg - (xAvg * xAvg))
            dy = np.sqrt(ySqrAvg - (yAvg * yAvg))
            dz = np.sqrt(zSqrAvg - (zAvg * zAvg))
            logging.info("position errors calculated")
            if (overwrite or Save):
                files_path = os.path.join(save_path, "files/")
                makedir2(files_path)
                logging.info("saving position calculation files in", str(files_path))
                save_np(files_path, xAvg, 'AverageX')
                save_np(files_path, yAvg, 'AverageY')
                save_np(files_path, zAvg, 'AverageZ')
                save_np(files_path, x, 'X')
                save_np(files_path, y, 'Y')
                save_np(files_path, z, 'Z')
                save_np(files_path,dx,'dx')
                save_np(files_path,dy,'dy')
                save_np(files_path,dz,'dz')
            if clear_intermediate:
                del probability,wavefun,xAvg,yAvg,zAvg,xSqrAvg,ySqrAvg,zSqrAvg
                logging.info("Intermediate variable deleted to conserve memory")
        logging.info("computing fourier transform to obtain k-space wavefunction")
        # logging.info("Making the finufft plan")
        if (time_points<=20000):
            logging.info("Time points are smaller than 20000 , Calculating normally")
            logging.info("Creating a memeory mapped wavefunction for finufft calculations")
            wavefun= np.load(save_path + 'Hilbert_trans_data.npy',mmap_mode='r').astype("complex128")
            logging.info("wavefun memory map complete")
            # logging.info("wavefun shape is",str(wavefun.shape))
            ft = finufft.nufft3d3(x=x, y=y, z=z, c=wavefun.transpose(), isign=-1, s=px_vals, t=py_vals,u=pz_vals, eps=10 ** -4)
            mom_wavefun = ft.transpose().astype('complex64')
            # logging.info("mom_wavefun shape is",str(mom_wavefun.shape))
            del ft
            logging.info("Fourier transform done")
            np.save(save_path + "momentum_wavefun2.npy", mom_wavefun)
            logging.info("Momentum wavefunction calculated and saved")
        elif (time_points>20000):
            logging.info("Time points are greater than 20000 , segmenting files and calculating")
            mom_wavefun =get_fourier_finuftt_large(x,y,z,px_vals=px_vals,py_vals=py_vals,pz_vals=pz_vals,file_path_wavefun=save_path + 'Hilbert_trans_data.npy',time_points=time_points,sources=No_sources,fourier_space_length=len(px_vals),output_folder=save_path)
            logging.info("Momentum wavefunction calculated and saved")
        if ((not(file_exists(save_path + 'Momentum_Probability.npy')) or overwrite) and(time_points<20000)):
            mom_sources=len(px_vals)
            phaseP, ampP, momentum_prob = norm_mom_prob(mom_wavefun,sources=mom_sources,time_points=time_points)
            if clear_intermediate:
                del mom_wavefun
            # save_file(momentum_prob,save_path,'Momentum_Probability.npy')
            np.save(save_path + 'Momentum_Probability.npy', momentum_prob)
            logging.info(",Momentum Probability Calculated and saved ")
            logging.info("Calculating Values with momentum probability")
            m = 1
            pxAvg = np.sum(momentum_prob * px_vals, axis=1)  # check and Recheck this code *********
            pyAvg = np.sum(momentum_prob * py_vals, axis=1)
            pzAvg = np.sum(momentum_prob * pz_vals, axis=1)

            pxsqrAvg = np.sum(momentum_prob * np.square(px_vals), axis=1)
            pyaqrAvg = np.sum(momentum_prob * np.square(py_vals), axis=1)
            pzaqrAvg = np.sum(momentum_prob * np.square(pz_vals), axis=1)
            # m should not be used here!
            dpx = m * np.sqrt(pxsqrAvg - (pxAvg * pxAvg))
            dpy = m * np.sqrt(pyaqrAvg - (pyAvg * pyAvg))
            dpz = m * np.sqrt(pzaqrAvg - (pzAvg * pzAvg))

                         #########  Saving Files #############
            if (overwrite or Save):
                files_path=os.path.join(save_path,"files/")
                makedir2(files_path)
                logging.info(f"saving files in",files_path)
                save_np(files_path,pxAvg,'AveragePX')
                save_np(files_path,pyAvg,'AveragePY')
                save_np(files_path,pzAvg,'AveragePZ')

                save_np(files_path, px_vals, 'px_vals')
                save_np(files_path, py_vals, 'py_vals')
                save_np(files_path, pz_vals, 'pz_vals')

                           ####### Plots ######
                plots_path=os.path.join(save_path,"Plots/")
                makedir2(plots_path)


    return logging.info("Pipeline run completed")

def QM_model_run_volume(data,x,y,z,px_vals,py_vals,pz_vals,save_path,time_points,No_sources,overwrite=False,Save=True,clear_intermediate=True):
    if (not(file_exists(save_path + 'momentum_wavefun2.npy'))or overwrite):
        if not file_exists(save_path + 'Hilbert_trans_data.npy'):
            logging.info("Performing Hilbert Transform and extracting position Probability")
            probability, wavefun = process_eeg_data2(data,sources=No_sources,time_points=time_points)
            logging.info("Hilbert Transform Done")
            logging.info("saving files")
            np.save(save_path + 'Probability_matrix.npy', probability)
            np.save(save_path + 'Hilbert_trans_data.npy', wavefun)
            logging.info("Position probability Calculated and saved")
            ####### Calculating Position values ########
            logging.info("calculating files for position probability ")
            xAvg = probability @ x  # check and Recheck this code *********
            yAvg = probability @ y
            zAvg = probability @ z
            logging.info("Average position values calculated")
            xSqrAvg = probability @ (x * x)
            ySqrAvg = probability @ (y * y)
            zSqrAvg = probability @ (z * z)
            logging.info("Average Squared values calculated")
            dx = np.sqrt(xSqrAvg - (xAvg * xAvg))
            dy = np.sqrt(ySqrAvg - (yAvg * yAvg))
            dz = np.sqrt(zSqrAvg - (zAvg * zAvg))
            logging.info("position errors calculated")
            if (overwrite or Save):
                files_path = os.path.join(save_path, "files/")
                makedir2(files_path)
                logging.info("saving position calculation files in", str(files_path))
                save_np(files_path, xAvg, 'AverageX')
                save_np(files_path, yAvg, 'AverageY')
                save_np(files_path, zAvg, 'AverageZ')
                save_np(files_path, x, 'X')
                save_np(files_path, y, 'Y')
                save_np(files_path, z, 'Z')
                save_np(files_path,dx,'dx')
                save_np(files_path,dy,'dy')
                save_np(files_path,dz,'dz')
            if clear_intermediate:
                del probability,wavefun,xAvg,yAvg,zAvg,xSqrAvg,ySqrAvg,zSqrAvg
                logging.info("Intermediate variable deleted to conserve memory")
        logging.info("computing fourier transform to obtain k-space wavefunction")
        # logging.info("Making the finufft plan")
        if (time_points<=20000):
            logging.info("Time points are smaller than 20000 , Calculating normally")
            logging.info("Creating a memeory mapped wavefunction for finufft calculations")
            wavefun= np.load(save_path + 'Hilbert_trans_data.npy',mmap_mode='r').astype("complex128")
            logging.info("wavefun memory map complete")
            ft = finufft.nufft3d3(x=x, y=y, z=z, c=wavefun.transpose().astype('complex128'), isign=-1, s=px_vals, t=py_vals,
                                  u=pz_vals, eps=10 ** -4)
            mom_wavefun = ft.transpose()
            del ft
            np.save(save_path + "momentum_wavefun2.npy", mom_wavefun)
            logging.info("Momentum wavefunction calculated and saved")
        elif (time_points>20000):
            logging.info("Time points are greater than 20000 , segmenting files and calculating")
            mom_wavefun =get_fourier_finuftt_large(x,y,z,px_vals=px_vals,py_vals=py_vals,pz_vals=pz_vals,file_path_wavefun=save_path + 'Hilbert_trans_data.npy',time_points=time_points,sources=No_sources,fourier_space_length=len(px_vals),output_folder=save_path)
            logging.info("Momentum wavefunction calculated and saved")
        if ((not(file_exists(save_path + 'Momentum_Probability.npy')) or overwrite) and(time_points<20000)):
            phaseP, ampP, momentum_prob = norm_mom_prob(mom_wavefun,sources=No_sources,time_points=time_points)
            if clear_intermediate:
                del mom_wavefun
            save_file(momentum_prob,save_path,'Momentum_Probability.npy')
            logging.info(",Momentum Probability Calculated and saved ")
            logging.info("Calculating Values with momentum probability")
            m = 1
            pxAvg = np.sum(momentum_prob * px_vals, axis=1)  # check and Recheck this code *********
            pyAvg = np.sum(momentum_prob * py_vals, axis=1)
            pzAvg = np.sum(momentum_prob * pz_vals, axis=1)

            pxsqrAvg = np.sum(momentum_prob * np.square(px_vals), axis=1)
            pyaqrAvg = np.sum(momentum_prob * np.square(py_vals), axis=1)
            pzaqrAvg = np.sum(momentum_prob * np.square(pz_vals), axis=1)
            dpx = m * np.sqrt(pxsqrAvg - (pxAvg * pxAvg))
            dpy = m * np.sqrt(pyaqrAvg - (pyAvg * pyAvg))
            dpz = m * np.sqrt(pzaqrAvg - (pzAvg * pzAvg))

            uncertainty_x = dpx * dx
            uncertainty_y = dpy * dy
            uncertainty_z = dpz * dz

                         #########  Saving Files #############
            if (overwrite or Save):
                files_path=os.path.join(save_path,"files/")
                makedir2(files_path)
                logging.info("saving files in",files_path)
                save_np(files_path,pxAvg,'AveragePX')
                save_np(files_path,pyAvg,'AveragePY')
                save_np(files_path,pzAvg,'AveragePZ')

                save_np(files_path, px_vals, 'px_vals')
                save_np(files_path, py_vals, 'py_vals')
                save_np(files_path, pz_vals, 'pz_vals')

                save_np(files_path, uncertainty_x, 'uncertainty_x')
                save_np(files_path, uncertainty_y, 'uncertainty_y')
                save_np(files_path, uncertainty_z, 'uncertainty_z')

                           ####### Plots ######
                plots_path=os.path.join(save_path,"Plots/")
                makedir2(plots_path)


    return logging.info("Pipeline run completed")