import numpy as np

from Utils.localization_func import *
from Utils.Ploting_functions import *
from Utils.QM_Model_functions import *
from Utils.Network_Extraction_TPM import *
from Utils.Telegram import *
import plotly.express as px
import gc
gc.enable()
###### fsAverage Template Common Files ######
mri_subject='fsaverage'
mri_folder='/home/brainlab-qm/FSL/Subjects_1'
bem_dir='/home/brainlab-qm/EEG_test/Output/Arci_test3/bem.fif' ### same for same template
# source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif'  # same for same template4
source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif'
# stc_file='/home/brainlab-qm/EEG_test/Output/Arci_test3/source'
stc_file='/home/brainlab-qm/EEG_test/Output/Arci_test4/source'
# stc_file=None
Time_limit=10000
#################3 Iteratable ###########
eeg_file='/home/brainlab-qm/EEG_test/Arci_test.set'
output_folder='/home/brainlab-qm/EEG_test/Output'
eeg_subject='Arci_test4'
forward_model_path=None
calculate_TPM=True
### Has to be calculated everytime
#Coregistration will be caculated everytime
#Noise Covariance will be calculated everytime
network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
                 'smhand', 'smmouth', 'ventral', 'frontoparietal']
folder=os.path.join(output_folder,eeg_subject)
makedir2(folder)
qm_save_path=os.path.join(output_folder,eeg_subject,"QM_model/")
makedir2(qm_save_path)

######### Parts to Run #######
perform_source_localization= True
QM_model=True
Network_extraction = True
logging.basicConfig(level=logging.INFO ,format='%(asctime)s %(levelname)s: %(message)s', handlers=[logging.StreamHandler(), logging.FileHandler(qm_save_path+'QM_Brain.log')])
if perform_source_localization:
    ############################## Source Reconstruction ###################
    if stc_file==None:
        logging.info("No stc file, Performing Source localization")
        stc= eeg_pipeline(eeg_file, output_folder,eeg_subject,mri_subject,mri_folder,bem_dir=bem_dir,Montage=None,source_space=source_space, forward_model_path=forward_model_path, normalization_method='sloreta',Time_limit=Time_limit)
        logging.info("Localization done, saving file")
        stc.save(folder+'/source',overwrite=True)
        logging.info("file saved")
        del stc
        logging.info("Variables deleted")
        gc.collect()
        stc = mne.read_source_estimate(folder+'/source')
        logging.info("Source file loaded from" + str(folder+'/source'))
        logging.info("file dimensions are" + str(stc.data.shape))
    else:
        stc = mne.read_source_estimate(stc_file)
        logging.info("Source file loaded from" + str(stc_file))

    x,y,z=get_coordinates_mni(stc,subject=mri_subject, subjects_dir=mri_folder)

    logging.info("Source localization Complete")


####################### QM Model ############

No_of_sources,time_points=get_data_information(stc)
logging.info(("The Data has " + str(No_of_sources) + " sources and " + str(time_points) + " Time points"))
data=extract_data(stc)
X,Y,Z =mni_to_meters(x,y,z)
px_vals,py_vals,pz_vals,len_kx,len_ky,len_kz= calc_k_space_3D(x,y,z,FOV_Red_Fac=1,Increment_Increase=0)
try:
    QM_model_run(data,X,Y,Z,px_vals,py_vals,pz_vals,save_path=qm_save_path,time_points=time_points,No_sources=No_of_sources,overwrite=True)
    gc.collect()
    probability=np.load(qm_save_path+"Probability_matrix.npy")
    logging.info("QM Model Complete")
    if calculate_TPM:
        logging.info("Calculating TPM")
        src=mne.read_source_spaces(source_space)
        tpm, tpm_per_source, frequency_of_entering_values, frequency_of_entering_values_per_source = tpm_pipeline_surface(QM_save_path=qm_save_path,src=src,probability=probability,time_points=time_points,mri_subject_dir=mri_folder,mri_subject='fsaverage')
        logging.info("TPM Calculated")
        network_save=os.path.join(qm_save_path,"network_analysis/")
        np.savetxt(network_save+"TPM.csv",tpm)
        np.savetxt(network_save+"TPM_per_source.csv",tpm_per_source)
        np.savetxt(network_save+"frequency_of_entering_values.csv",frequency_of_entering_values)
        fig = px.imshow(tpm_per_source,x=network_names,y=network_names)
        fig.write_image("/home/brainlab-qm/EEG_test/Output/Arci_test4/QM_model/Plots/tpm_per_source.png")
        fig = px.imshow(tpm,x=network_names,y=network_names)
        fig.write_image("/home/brainlab-qm/EEG_test/Output/Arci_test4/QM_model/Plots/tpm.png")
        gc.collect()
    status = "No errors"
except Exception as e:
    logging.info(str(e))
    send_message("Code error "+str(e))
    status="Error in execution"
send_message(message="Code completed with "+str(status))