import os
import logging
import gc
import glob
import plotly.express as px
import mne
import numpy as np
from Utils.localization_func_with_reporting import *
from Utils.Ploting_functions import *
from Utils.QM_Model_functions import *
from Utils.Network_Extraction_TPM import *
from Utils.Telegram import *

# Configuration
config = {
    'mri_subject': 'fsaverage',
    'mri_folder': '/home/brainlab-qm/FSL/Subjects_1',
    'eeg_folder': '/home/brainlab-qm/EEG_test/tinnitus',
    'output_folder': '/home/brainlab-qm/EEG_test/Output',
    'forward_model_path': None,
    'calculate_TPM': True,
    'Time_limit': 40000,
    'network_names': ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
                 'smhand', 'smmouth', 'ventral', 'frontoparietal']
}

# Enable garbage collector
gc.enable()

# Define paths
bem_dir = os.path.join(config['mri_folder'], config['mri_subject'], "Pipeline", "bem.fif")
source_space = os.path.join(config['mri_folder'], config['mri_subject'], "Pipeline", "source-src.fif")

# Create directories
os.makedirs(config['output_folder'], exist_ok=True)
qm_save_path = os.path.join(config['output_folder'], "QM_model/")
os.makedirs(qm_save_path, exist_ok=True)

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s',
                    handlers=[logging.StreamHandler(), logging.FileHandler(os.path.join(qm_save_path, 'QM_Brain.log'))])

# Get EEG files
eeg_files = glob.glob(os.path.join(config['eeg_folder'], '*.txt'))

for eeg_file in eeg_files:
    # Get EEG subject name
    eeg_subject = os.path.splitext(os.path.basename(eeg_file))[0]

    # Create output folder for EEG subject
    folder = os.path.join(config['output_folder'], eeg_subject)
    os.makedirs(folder, exist_ok=True)

    # Perform source localization
    stc_file = os.path.join(folder, 'source')
    if not os.path.isfile(stc_file + '-lh.stc'):
        try:
            logging.info(f"No stc file for {eeg_subject}, Performing Source localization")
            stc = eeg_pipeline(eeg_file, config['output_folder'], eeg_subject, config['mri_subject'], config['mri_folder'], bem_dir=bem_dir,
                               source_space=source_space, forward_model_path=config['forward_model_path'], normalization_method='sloreta',
                               Time_limit=config['Time_limit'], report_path=folder)
            stc.save(stc_file, overwrite=True)
            del stc
        except Exception as e:
            logging.error(f"Error during source localization for {eeg_subject}: {e}")
            send_message(f"Code error for {eeg_subject}: {e}")
        finally:
            gc.collect()

    # Load source file
    try:
        stc = mne.read_source_estimate(stc_file)
        logging.info(f"Source file for {eeg_subject} loaded from {stc_file}")
        logging.info(f"File dimensions are {stc.data.shape}")
    except Exception as e:
        logging.error(f"Error loading source file for {eeg_subject}: {e}")
        send_message(f"Code error for {eeg_subject}: {e}")

    # Get coordinates
    try:
        x, y, z = get_coordinates_mni(stc, subject=config['mri_subject'], subjects_dir=config['mri_folder'])
        logging.info(f"Source localization for {eeg_subject} complete")
    except Exception as e:
        logging.error(f"Error getting coordinates for {eeg_subject}: {e}")
        send_message(f"Code error for {eeg_subject}: {e}")

    # QM Model
    try:
        No_of_sources, time_points = get_data_information(stc)
        logging.info(f"The data for {eeg_subject} has {No_of_sources} sources and {config['Time_limit']} time points")
        data = extract_data(stc)
        X, Y, Z = mni_to_meters(x, y, z)
        px_vals, py_vals, pz_vals, len_kx, len_ky, len_kz = calc_k_space_3D(x, y, z, FOV_Red_Fac=1, Increment_Increase=0)
        QM_model_run(data, X, Y, Z, px_vals, py_vals, pz_vals, save_path=qm_save_path, time_points=time_points,
                     No_sources=No_of_sources, overwrite=True)
        gc.collect()
        probability = np.load(os.path.join(qm_save_path, "Probability_matrix.npy"))
        logging.info(f"QM Model for {eeg_subject} complete")
    except Exception as e:
        logging.error(f"Error during QM Model for {eeg_subject}: {e}")
        send_message(f"Code error for {eeg_subject}: {e}")

    # Calculate TPM
    if config['calculate_TPM']:
        try:
            logging.info(f"Calculating TPM for {eeg_subject}")
            src = mne.read_source_spaces(source_space)
            tpm, tpm_per_source, frequency_of_entering_values, frequency_of_entering_values_per_source = tpm_pipeline_surface(
                QM_save_path=qm_save_path, src=src, probability=probability, time_points=time_points,
                mri_subject_dir=config['mri_folder'], mri_subject='fsaverage')
            logging.info(f"TPM calculation for {eeg_subject} complete")

            network_save = os.path.join(qm_save_path, "network_analysis/")
            os.makedirs(network_save, exist_ok=True)

            np.savetxt(os.path.join(network_save, f"TPM_{eeg_subject}.csv"), tpm)
            np.savetxt(os.path.join(network_save, f"TPM_per_source_{eeg_subject}.csv"), tpm_per_source)
            np.savetxt(os.path.join(network_save, f"frequency_of_entering_values_{eeg_subject}.csv"), frequency_of_entering_values)

            report_path = os.path.join(qm_save_path, "Plots/")
            os.makedirs(report_path, exist_ok=True)

            fig = px.imshow(tpm_per_source, x=config['network_names'], y=config['network_names'])
            fig.write_image(os.path.join(report_path, f"tpm_per_source_{eeg_subject}.png"))

            fig = px.imshow(tpm, x=config['network_names'], y=config['network_names'])
            fig.write_image(os.path.join(report_path, f"tpm_{eeg_subject}.png"))

            gc.collect()
        except Exception as e:
            logging.error(f"Error during TPM calculation for {eeg_subject}: {e}")
            send_message(f"Code error for {eeg_subject}: {e}")

    send_message(message=f"Code completed for {eeg_subject}")
