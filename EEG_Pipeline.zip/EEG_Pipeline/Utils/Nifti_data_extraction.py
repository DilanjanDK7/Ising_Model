import nibabel as nib
import numpy as np
from nilearn.maskers import NiftiMasker, NiftiLabelsMasker
from nilearn.input_data import NiftiMapsMasker
import nilearn.datasets as nds
from nilearn import plotting
from nilearn.connectome import ConnectivityMeasure





print("Loading data...")

def select_atlas(atlas_id, **kwargs):
    """
       Selects and fetches a brain atlas based on the given atlas_id and optional keyword arguments.
       Only the atlas ID's 1,5,7,8,11,14 are working as of now.
       for 3,4,12,13,14 ID's , They have subdictionaries and need to be handled differently.By selecting the needed resolution/network within the atlas (Maps Issue)
       for 2,6,9,10,15 ID's , They have subdictionaries and need to be handled differently.By selecting the needed resolution/network within the atlas(4D/3D issue)
       Available atlas options and their keyword arguments:

       Atlas ID 1: AAL
           - resolution: '1mm' or '2mm' (default='1mm')

       Atlas ID 2: Allen 2011
           - resolution: '25', '50', '100', or '200' (default='2')

       Atlas ID 3: BASC Multiscale
           - scale: 7, 12, 20, 36, 64, 122, 197, or 325 (default=122)

       Atlas ID 4: Craddock 2012
           - scale: 49, 60, 78, 98, 200, or 500 (default=200)

       Atlas ID 5: Destrieux 2009
           - resolution: '1.5mm' or '2mm' (default='1.5mm')

       Atlas ID 6: Difumo
           - scale: 64, 128, 256, or 512 (default=256)

       Atlas ID 7: Harvard-Oxford Cortical
           - symmetric_split: bool (default=False)

       Atlas ID 8: Juelich Histological
           - symmetric_split: bool (default=False)

       Atlas ID 9: MSDL
           - scaling_param: float (default=1.0)

       Atlas ID 10: Pauli 2017
           - scale: 125 or 250 (default=250)

       Atlas ID 11: Schaefer 2018
           - scale: 100, 200, 300, 400, or 500 (default=200)


       Atlas ID 12: Smith 2009
           - symmetric_split: bool (default=False)

       Atlas ID 13: Destrieux 2009 Surface
           - hemisphere: 'left' or 'right' (default='both')
           - inflated: bool (default=True)
           - annot: 'aparc' or 'aparc.a2009s' (default='aparc.a2009s')

       Atlas ID 14: Talairach
           - level: 'gyrus', 'lobe', 'gyrus_region', 'lobe_region', 'gyrus_colin', or 'lobe_colin' (default='gyrus')
           - hemisphere: 'left' or 'right' (default='both')

       Atlas ID 15: Yeo 2011
           - resolution: '17', '7', or '100' (default='17')

       :param atlas_id: An integer representing the desired atlas.
       :param kwargs: Optional keyword arguments specific to the chosen atlas.
       :return: The selected atlas, fetched using Nilearn.
       :raises ValueError: If an invalid atlas_id is provided.
       """
    if atlas_id == 1:
        atlas = nds.fetch_atlas_aal(**kwargs)
    elif atlas_id == 2:
        atlas = nds.fetch_atlas_allen_2011(**kwargs)
    elif atlas_id == 3:
        atlas = nds.fetch_atlas_basc_multiscale_2015(**kwargs)
    elif atlas_id == 4:
        atlas = nds.fetch_atlas_craddock_2012(**kwargs)
    elif atlas_id == 5:
        atlas = nds.fetch_atlas_destrieux_2009(**kwargs)
    elif atlas_id == 6:
        atlas = nds.fetch_atlas_difumo(**kwargs)
    elif atlas_id == 7:
        atlas = nds.fetch_atlas_harvard_oxford('cort-maxprob-thr25-2mm', **kwargs)
    elif atlas_id == 8:
        atlas = nds.fetch_atlas_juelich('maxprob-thr25-2mm', **kwargs)
    elif atlas_id == 9:
        atlas = nds.fetch_atlas_msdl(**kwargs)
    elif atlas_id == 10:
        atlas = nds.fetch_atlas_pauli_2017(**kwargs)
    elif atlas_id == 11:
        atlas = nds.fetch_atlas_schaefer_2018(**kwargs)
    elif atlas_id == 12:
        atlas = nds.fetch_atlas_smith_2009(**kwargs)
    elif atlas_id == 13:
        atlas = nds.fetch_atlas_surf_destrieux(**kwargs)
    elif atlas_id == 14:
        atlas = nds.fetch_atlas_talairach('gyrus', **kwargs)
    elif atlas_id == 15:
        atlas = nds.fetch_atlas_yeo_2011(**kwargs)
    else:
        raise ValueError("Invalid atlas_id. Please select an integer from 1 to 15.")
    return atlas

def extract_data(nifti_file, atlas_id, **kwargs):
    atlas = select_atlas(atlas_id, **kwargs)
    masker = NiftiLabelsMasker(labels_img=atlas.maps, standardize=True, memory='nilearn_cache', verbose=5)
    data = masker.fit_transform(nifti_file)
    return data

def plot_atlas(atlas_id,resolution_id3="006",**kwargs):
    atlas = select_atlas(atlas_id, **kwargs)
    atlas.plot()
    if atlas_id == 1 or  atlas_id == 5 or atlas_id == 7 or atlas_id == 8 or atlas_id == 11 or atlas_id == 14 :
        atlas_filename = atlas.maps
    if atlas_id==3:
             networks_file = atlas["scale{}".format(str(resolution_id3).zfill(3))]
             atlas_filename = networks_file

    plotting.plot_roi(atlas_filename, title="Atlas regions")

def compute_correlation_matrix(time_series):
    correlation_measure = ConnectivityMeasure(kind="correlation")
    correlation_matrix = correlation_measure.fit_transform([time_series])[0]
    np.fill_diagonal(correlation_matrix, 0)
    ####labels = atlas.labels#######
    plotting.plot_matrix(
        correlation_matrix,
        figure=(10, 8),
        labels=labels[1:],
        vmax=0.8,
        vmin=-0.8,
        title="Correlation matrix",
        reorder=True,
    )
    return correlation_matrix

print("Done.")


img=nib.load("/home/brainlab-qm/EEG_test/Output/Arci_test_volume/source_estimate.nii.gz")
img_data=img.get_fdata()
img_affine=img.affine
img_header=img.header


def get_time_series(atlas,time_series):
    atlas_filename = atlas.maps
    labels = atlas.labels
    masker = NiftiLabelsMasker(
        labels_img=atlas_filename,
        standardize=True,
        memory="nilearn_cache",
        verbose=5,
    )
    time_series = masker.fit_transform(img)
    return time_series

atlas = select_atlas(1)