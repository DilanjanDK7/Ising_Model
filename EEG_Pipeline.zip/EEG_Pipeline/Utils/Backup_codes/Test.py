import mne
import nbclassic.i18n
import nilearn.regions
import numpy as np

from Utils.localization_func import *
from Utils.Network_Extraction_TPM import *

mri_subject='fsaverage'
mri_folder='/home/brainlab-qm/FSL/Subjects_1'
bem_dir='/home/brainlab-qm/EEG_test/Output/Arci_test3/bem.fif' ### same for same template
# source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif'  # same for same template4
source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif'
# stc_file='/home/brainlab-qm/EEG_test/Output/Arci_test3/source'
# stc_file='/home/brainlab-qm/EEG_test/Output/Arci_test4/source'
stc_file=None
eeg_file='/home/brainlab-qm/EEG_test/Arci_test.set'
output_folder='/home/brainlab-qm/EEG_test/Output'
eeg_subject='Arci_test4'
forward_model_path=None
folder=os.path.join(output_folder,eeg_subject)
makedir2(folder)
qm_save_path=os.path.join(output_folder,eeg_subject,"QM_model/")
makedir2(qm_save_path)

perform_source_localization= True
QM_model=True
Network_extraction = True
# if perform_source_localization:
#     ############################## Source Reconstruction ###################
#     if stc_file==None:
#         stc= eeg_pipeline(eeg_file, output_folder,eeg_subject,mri_subject,mri_folder,bem_dir=bem_dir,Montage=None,source_space=source_space, forward_model_path=forward_model_path, normalization_method='sloreta')
#         logging.info("Localization done, saving file")
#         stc.save(folder+'/source',overwrite=True)
#         logging.info("file saved")
#         del stc
#         logging.info("Variables deleted")
#         gc.collect()
#         stc = mne.read_source_estimate(folder+'/source')
#     else:
#         stc = mne.read_source_estimate(stc_file)
#         logging.info("Source file loaded from" + str(stc_file))
#
#     x,y,z=get_coordinates_mni(stc,subject=mri_subject, subjects_dir=mri_folder)
#
#     logging.info("Source localization Complete")

network_name ="Visual_parcellation_5"
source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif'
src=mne.read_source_spaces(source_space,verbose=True)

vert_lh,vert_rh = get_vertices_of_network(network_name,src,mri_subject,mri_subjects_dir=mri_folder,Visualize= False)


visual='/home/brainlab-qm/FSL/RSN_Parcellations/Visual_parcellation_5.nii'
img = nb.load(visual)
regions = nilearn.regions.connected_regions(img)
io.write_annot('/home/brainlab-qm/FSL/RSN_Parcellations/visual.annot',)

import nibabel as nib
from nibabel.freesurfer.io import write_annot
from nibabel.freesurfer import io

def convert_nii_to_annot_regions(nii_file,annot_file):
    img = nb.load(nii_file)
    regions = nilearn.regions.connected_regions(img)
    io.write_annot(annot_file,regions[0],regions[1],regions[2])

def convert_nii_to_annot_(nii_file,annot_file):
    nii_file=nib.load(nii_file)
    data=nii_file.get_fdata()
    data=data.astype(int)
    write_annot(annot_file,data,np.arange(1,data.max()+1),np.arange(1,data.max()+1))

convert_nii_to_annot_('/home/brainlab-qm/FSL/RSN_Parcellations/Visual_parcellation_5.nii','/home/brainlab-qm/FSL/RSN_Parcellations/Converted/Source_space/Visual_parcellation_5.annot')

new_tpm,tpm_per_source,frequency_of_entering_values,frequency_of_entering_values_per_source = make_tpm_new_object(data,time_points,no_of_networks,diagonal=True,normalise=False,Calculate_per_unit_source=False)
new_tpm,tpm_per_source,frequency_of_entering_values,frequency_of_entering_values_per_source = make_tpm_new_object(data=total_network_probability,time_points=121046,no_of_networks=12,diagonal=True,normalise=False,Calculate_per_unit_source=False)