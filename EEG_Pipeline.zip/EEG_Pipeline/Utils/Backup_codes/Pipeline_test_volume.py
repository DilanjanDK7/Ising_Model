import logging
from Utils.localization_func import *
from Utils.Ploting_functions import *
from Utils.QM_Model_functions import *
from Utils.Network_Extraction_TPM import *
from Utils.Telegram import *
from Utils.localization_func_volume import *
import gc
gc.enable()
###### fsAverage Template Common Files ######
mri_subject='fsaverage'
mri_folder='/home/brainlab-qm/FSL/Subjects_1'
bem_dir="/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/bem.fif" ### same for same template
# source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif'  # same for same template4
source_space="/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source_vol-src.fif"
# stc_file='/home/brainlab-qm/EEG_test/Output/Arci_test5/source-vl.stc'
# stc_file='/home/brainlab-qm/EEG_test/Output/Arci_test4/source'
stc_file=None
#################3 Iteratable ###########
eeg_file='/home/brainlab-qm/EEG_test/Arci_test.set'
output_folder='/home/brainlab-qm/EEG_test/Output'
eeg_subject='Arci_test_volume'
forward_model_path=None

### Has to be calculated everytime
#Coregistration will be caculated everytime
#Noise Covariance will be calculated everytime

folder=os.path.join(output_folder,eeg_subject)
makedir2(folder)
qm_save_path=os.path.join(output_folder,eeg_subject,"QM_model/")
makedir2(qm_save_path)

######### Parts to Run #######
perform_source_localization= True
QM_model=True
Network_extraction = True
logging.basicConfig(level=logging.INFO ,format='%(asctime)s %(levelname)s: %(message)s', handlers=[logging.StreamHandler(), logging.FileHandler(qm_save_path+'QM_Brain.log')])
if perform_source_localization:
    ############################## Source Reconstruction ###################
    if stc_file==None:
        logging.info("No stc file, Performing Source localization")
        stc= eeg_pipeline_volume(eeg_file, output_folder,eeg_subject,mri_subject,mri_folder,bem_dir=bem_dir,Montage=None,source_space=source_space, forward_model_path=forward_model_path,Time_limit=6000,normalization_method='sloreta')
        logging.info("Localization done, saving file")
        stc.save(folder+'/source',overwrite=True)
        path_save_source= os.path.join(mri_folder,mri_subject, 'Pipeline/')
        source_space_path=path_save_source+"source_vol-src.fif"
        logging.info("file saved")
        src=mne.read_source_spaces(source_space_path, patch_stats=False, verbose=True)
        stc.save_as_volume(fname=folder+'/source_estimate.nii.gz', src=src, dest='mri', mri_resolution=False, format='nifti2',overwrite=True, verbose=True)
        logging.info("file saved as Nifti")
        del stc
        logging.info("Variables deleted")
        gc.collect()
        stc = mne.read_source_estimate(folder+'/source-vl.stc')
    else:
        stc = mne.read_source_estimate(stc_file)
        logging.info("Source file loaded from" + str(stc_file))

    x,y,z=get_coordinates_mni(stc,subject=mri_subject, subjects_dir=mri_folder)

    logging.info("Source localization Complete")


####################### QM Model ############

No_of_sources,time_points=get_data_information(stc)
logging.info(("The Data has " + str(No_of_sources) + " sources and " + str(time_points) + " Time points"))
data=extract_data(stc)
X,Y,Z =mni_to_meters(x,y,z)
px_vals,py_vals,pz_vals,len_kx,len_ky,len_kz= calc_k_space_3D(x,y,z,FOV_Red_Fac=1,Increment_Increase=0)
try:
    probability = QM_model_run(data,X,Y,Z,px_vals,py_vals,pz_vals,save_path=qm_save_path,time_points=time_points,No_sources=No_of_sources,overwrite=False)
    status = "No errors"
except Exception as e:
    logging.info(str(e))
    send_message("Code error"+str(e))
    status="Error in execution"
send_message(message="Code completed with"+str(status))