import numpy as np

from Utils.localization_func import *
from Utils.Ploting_functions import *
from Utils.QM_Model_functions import *
from Utils.Network_Extraction_TPM import *
from Utils.Telegram import *

"""
In this python File I exract the vertices that correspond to each network ( Obtained through fmri)
and the label is restricted to the src space and the vertices are extracted. In order to plot
the corrected label (cluster0) first the labels will be corrected in the full white surf space, and the potting is done
thereafter, the same process of inversion if done to get the subsampled vertices in the src file - DK

"""

##### Leading Networks#####

#### add the subject name and the subject directory
mri_subject='fsaverage'
mri_subject_dir='/home/brainlab-qm/FSL/Subjects_1'
save_path = '/home/brainlab-qm/EEG_test/Output/Arci_test4/' # where the label will be saved
src = mne.read_source_spaces('/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source-src.fif') # the source space file
networks_lh,networks_rh,names,names_full = load_networks_hemi(mri_subject,mri_subject_dir,read_networks=True,surf_name='white')

#### for the Subsampled Source Space ###
all_network_vertices_lh,all_network_vertices_rh = get_vertices_first_network_src_restricted(networks_lh,networks_rh,src,save_path=save_path,network_names=None,save=True)

#### for the Full Source Space ###
all_network_vertices_lh_full,all_network_vertices_rh_full= get_vertices_first_network_corrected(networks_lh,networks_rh,src,save_path=save_path,network_names=None,save=True,full_src=True)

def get_vertices_src_for_prob_extraction(mri_subject,mri_subject_dir,save_path,src,save=True):
    """
    This function will extract the vertices of the first Cluster of the network labels in the restricted src space
    :param mri_subject:
    :param mri_subject_dir:
    :param save_path:
    :param src:
    :param save:
    :return:
    """
    networks_lh,networks_rh,names,names_full = load_networks_hemi(mri_subject,mri_subject_dir,read_networks=True,surf_name='white')
    all_network_vertices_lh,all_network_vertices_rh = get_vertices_first_network_src_restricted(networks_lh,networks_rh,src,save_path=save_path,network_names=None,save=save)
    vertices_lh=np.empty(shape=(len(names)),dtype=object)
    vertices_rh=np.empty(shape=(len(names)),dtype=object)
    total_vertices_lh=np.empty(shape=1)
    total_vertices_rh=np.empty(shape=1)
    for name in names:
        logging.info("Extracting vertices for %s"%name)
        vertices_rh[names.index(name)]=all_network_vertices_rh[names.index(name)][0][0]
        vertices_lh[names.index(name)]=all_network_vertices_lh[names.index(name)][0][0]
        total_vertices_lh=total_vertices_lh+vertices_lh[names.index(name)].shape
        total_vertices_rh=total_vertices_rh+vertices_rh[names.index(name)].shape
    return vertices_lh,vertices_rh,total_vertices_lh,total_vertices_rh

vertices_lh,vertices_rh,total_vertices_lh,total_vertices_rh  = get_vertices_src_for_prob_extraction(mri_subject,mri_subject_dir,save_path,src,save=True)