import mne
import nibabel as nib
import numpy as np

def extract_sources_from_nii(nii_file, src_file, stc_file):
    # Load the NIfTI file containing the binary mask
    mask_img = nib.load(nii_file)
    mask_data = mask_img.get_fdata().astype(bool)

    # Load the volume source space
    src = mne.read_source_spaces(src_file)

    # Find the source space vertices that fall within the region of interest
    inuse = src[0]['inuse'].astype(bool)
    vertno = src[0]['vertno']
    rr = src[0]['rr'][inuse]
    ijk = mne.transforms.apply_trans(np.linalg.inv(mask_img.affine), rr)
    ijk = np.round(ijk).astype(int)
    mask = mask_data[ijk[:, 0], ijk[:, 1], ijk[:, 2]]
    vertices = vertno[mask]

    # Load the volume source estimates
    stc = mne.read_source_estimate(stc_file)

    # Extract the sources belonging to the region of interest
    stc_label = stc.in_label(vertices)

    return stc_label,vertices

def extract_source_vertices_fsaverage(nii_file, src_file,mri_subject,mri_subject_folder):

    return vertices

source_space='/home/brainlab-qm/FSL/Subjects_1/fsaverage/Pipeline/source_vol-src.fif'
nii_file="/home/brainlab-qm/FSL/RSN_Parcellations/template_fixed/Visual_parcellation_5.nii"
stc_file="/home/brainlab-qm/EEG_test/Output/Arci_test4/source"

stc_label,vertices=extract_sources_from_nii(nii_file, source_space, stc_file)

print("Done")

import mne
import nibabel as nib
import numpy as np

def extract_sources_from_nii(nii_file, src_file, stc_file):
    # Load the NIfTI file containing the binary mask
    mask_img = nib.load(nii_file)
    mask_data = mask_img.get_fdata().astype(bool)

    # Load the volume source space
    src = mne.read_source_spaces(src_file)

    # Find the source space vertices that fall within the region of interest
    inuse = src[0]['inuse'].astype(bool)
    vertno = src[0]['vertno']
    rr = src[0]['rr'][inuse]
    ijk = mne.transforms.apply_trans(np.linalg.inv(mask_img.affine), rr)
    ijk = np.round(ijk).astype(int)
    mask = mask_data[ijk[:, 0], ijk[:, 1], ijk[:, 2]]
    vertices = vertno[mask]

    # Load the volume source estimates
    stc = mne.read_source_estimate(stc_file)

    # Extract the sources belonging to the region of interest
    stc_label = stc.in_label(vertices)

    return stc_label