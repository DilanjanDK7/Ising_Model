import logging
import json
import requests

def load_config_file(config_path):
    global TOKEN, CHAT_ID
    with open(config_path) as f:
        data = json.load(f)
        TOKEN = data.get('token')
        CHAT_ID = data.get('chat_id')

def save_config_file(config_path, token, chat_id):
    data = {'token': token, 'chat_id': chat_id}
    with open(config_path, 'w') as f:
        json.dump(data, f)

def send_telegram_message(message):
    chat_id = "5797897976"
    TOKEN = "6071801919:AAGErfVqKXY-rYecsP29RiJWttBIZ2QwOBE"
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={chat_id}&text={message}"
    response = requests.get(url).json()
    if response['ok']:
        print('Message sent successfully!')
    else:
        print('Failed to send message.')

def send_message(message):
    # Prompt user for config file path
    # config_path = input('Enter path to config file: ')

    # Load config file or ask for bot token and chat ID

    # message = input('Enter message to send: ')
    send_telegram_message(message)
    return logging.info("Telegram message sent")