import gc
import os.path

import mne
import logging
import nibabel as nib
import mne
import numpy as np


###########################  NETWORK EXTRACTION FUNCTIONS ########################

def apply_mask():
    stc = mne.read_source_estimate('reconstructed_source_data.stc')

    # Load the mask data
    mask_data = mne.read_source_spaces('mask_data.fif')

    # Apply the mask to the source data
    masked_data = stc.copy().crop(None, None, mask_data.vertices[0], copy=True)

    # Extract the sources within the mask
    sources_within_mask = masked_data.extract_label_time_course(mask_data.labels, src=masked_data.vertices, mode='mean')

    # Print the sources within the mask
    print(sources_within_mask)

def load_networks(mri_subject,mri_subject_dir,read_networks=True,surf_name='white'):
    names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
             'smhand', 'smmouth', 'ventral', 'frontoparietal',]
    names_full = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
                  'smhand', 'smmouth', 'ventral', 'frontoparietal', 'Other']

    if read_networks:
        auditory =mne.read_labels_from_annot(subject=mri_subject, parc='Auditory_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        visual = mne.read_labels_from_annot(subject=mri_subject, parc='Visual_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        cingulooperc = mne.read_labels_from_annot(subject=mri_subject, parc='CinguloOperc_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        cingulopari = mne.read_labels_from_annot(subject=mri_subject, parc='CinguloParietal_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        default = mne.read_labels_from_annot(subject=mri_subject, parc='Default_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        dorsal = mne.read_labels_from_annot(subject=mri_subject, parc='DorsalAttn_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        retrosplenial = mne.read_labels_from_annot(subject=mri_subject, parc='RetrosplenialTemporal_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        salience = mne.read_labels_from_annot(subject=mri_subject, parc='Salience_parcellation_4', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        smhand = mne.read_labels_from_annot(subject=mri_subject, parc='SMhand_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        smmouth = mne.read_labels_from_annot(subject=mri_subject, parc='SMmouth_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        ventral = mne.read_labels_from_annot(subject=mri_subject, parc='VentralAttn_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        frontoparietal = mne.read_labels_from_annot(subject=mri_subject, parc='FrontoParietal_parcellation_5', hemi='both', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)

        networks = [auditory, visual, cingulooperc, cingulopari, default, dorsal, retrosplenial, salience, smhand, smmouth, ventral, frontoparietal]
    return networks,names,names_full

def load_networks_hemi(mri_subject,mri_subject_dir,read_networks=True,surf_name='white'):
    names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
             'smhand', 'smmouth', 'ventral', 'frontoparietal']
    names_full = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
                  'smhand', 'smmouth', 'ventral', 'frontoparietal', 'Other']

    if read_networks:
        auditory_lh =mne.read_labels_from_annot(subject=mri_subject, parc='Auditory_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        visual_lh = mne.read_labels_from_annot(subject=mri_subject, parc='Visual_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        cingulooperc_lh = mne.read_labels_from_annot(subject=mri_subject, parc='CinguloOperc_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        cingulopari_lh = mne.read_labels_from_annot(subject=mri_subject, parc='CinguloParietal_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        default_lh = mne.read_labels_from_annot(subject=mri_subject, parc='Default_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        dorsal_lh = mne.read_labels_from_annot(subject=mri_subject, parc='DorsalAttn_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        retrosplenial_lh = mne.read_labels_from_annot(subject=mri_subject, parc='RetrosplenialTemporal_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        salience_lh = mne.read_labels_from_annot(subject=mri_subject, parc='Salience_parcellation_4', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        smhand_lh = mne.read_labels_from_annot(subject=mri_subject, parc='SMhand_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        smmouth_lh = mne.read_labels_from_annot(subject=mri_subject, parc='SMmouth_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        ventral_lh = mne.read_labels_from_annot(subject=mri_subject, parc='VentralAttn_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        frontoparietal_lh = mne.read_labels_from_annot(subject=mri_subject, parc='FrontoParietal_parcellation_5', hemi='lh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)

        auditory_rh = mne.read_labels_from_annot(subject=mri_subject, parc='Auditory_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        visual_rh = mne.read_labels_from_annot(subject=mri_subject, parc='Visual_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        cingulooperc_rh = mne.read_labels_from_annot(subject=mri_subject, parc='CinguloOperc_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        cingulopari_rh = mne.read_labels_from_annot(subject=mri_subject, parc='CinguloParietal_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        default_rh = mne.read_labels_from_annot(subject=mri_subject, parc='Default_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        dorsal_rh = mne.read_labels_from_annot(subject=mri_subject, parc='DorsalAttn_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        retrosplenial_rh = mne.read_labels_from_annot(subject=mri_subject, parc='RetrosplenialTemporal_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        salience_rh = mne.read_labels_from_annot(subject=mri_subject, parc='Salience_parcellation_4', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        smhand_rh = mne.read_labels_from_annot(subject=mri_subject, parc='SMhand_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        smmouth_rh = mne.read_labels_from_annot(subject=mri_subject, parc='SMmouth_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        ventral_rh = mne.read_labels_from_annot(subject=mri_subject, parc='VentralAttn_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)
        frontoparietal_rh = mne.read_labels_from_annot(subject=mri_subject, parc='FrontoParietal_parcellation_5', hemi='rh', surf_name=surf_name, annot_fname=None, regexp=None, subjects_dir=mri_subject_dir, sort=True, verbose=True)

        networks_lh = [auditory_lh, visual_lh, cingulooperc_lh, cingulopari_lh, default_lh, dorsal_lh, retrosplenial_lh, salience_lh, smhand_lh, smmouth_lh, ventral_lh, frontoparietal_lh]
        networks_rh = [auditory_rh, visual_rh, cingulooperc_rh, cingulopari_rh, default_rh, dorsal_rh, retrosplenial_rh, salience_rh, smhand_rh, smmouth_rh, ventral_rh, frontoparietal_rh]

    return networks_lh,networks_rh,names,names_full

def get_network_vertices_restricted_src(networks_lh,networks_rh,src,save_path=None,network_names=None,save=True):
    """Get vertices for each network in a restricted source space.

    Parameters
    ----------
    networks_lh : list
        List of labels for each network in the left hemisphere.
    networks_rh : list
        List of labels for each network in the right hemisphere.
    src : instance of SourceSpaces
        Source space.

    Returns
    -------
    network_vertices : dict
        Dictionary of network vertices.
    """
    all_network_vertices_lh = []
    all_network_vertices_rh = []
    if save is True:
        if save_path is None:
            ValueError('Please specify a save path.')
        save_path = os.path.join(save_path, 'network_vertices/')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
    if network_names is None:
        network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
    for network in network_names:
        vertices_network_lh = []
        vertices_network_rh = []
        for i in range(len(networks_lh[network_names.index(network)])):
            vertices_lh=networks_lh[network_names.index(network)][i].restrict(src).vertices
            vertices_rh=networks_rh[network_names.index(network)][i].restrict(src).vertices
            vertices_network_lh.append(vertices_lh)
            vertices_network_rh.append(vertices_rh)
        np.save(save_path+network+'_'+str(i)+'_lh.npy',vertices_network_lh)
        np.save(save_path+network+'_'+str(i)+'_rh.npy',vertices_network_rh)
        all_network_vertices_lh.append(vertices_network_lh)
        all_network_vertices_rh.append(vertices_network_rh)
    return np.array(all_network_vertices_lh,dtype='object'),np.array(all_network_vertices_rh,dtype='object')

def get_vertices_first_network_corrected(networks_lh,networks_rh,src,save_path=None,network_names=None,save=True):
    """Get vertices for each network in the full space .

    Parameters
    ----------
    networks_lh : list
        List of labels for each network in the left hemisphere.
    networks_rh : list
        List of labels for each network in the right hemisphere.
    src : instance of SourceSpaces
        Source space.

    Returns
    -------
    network_vertices : dict
        Dictionary of network vertices.
    """
    all_network_vertices_lh = []
    all_network_vertices_rh = []
    total_vertices = np.arange(src[0]['np'])
    if save is True:
        if save_path is None:
            ValueError('Please specify a save path.')
        save_path = os.path.join(save_path, 'network_vertices/')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
    if network_names is None:
        network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
    for network in network_names:
        vertices_network_lh = []
        vertices_network_rh = []

        labels_lh=networks_lh[network_names.index(network)]
        left_label =[label for label in labels_lh if label.name == 'cluster0-lh'][0]
        new_label_lh = left_label.copy()
        new_vertices_lh = np.array([i for j, i in enumerate(total_vertices) if j not in left_label.vertices])
        new_label_lh.vertices = new_vertices_lh
        new_label_lh.hemi = 'lh'
        new_label_lh.name = 'cluster0-lh'
        vertices_lh=new_label_lh.restrict(src).vertices

        labels_rh=networks_rh[network_names.index(network)]
        right_label =[label for label in labels_rh if label.name == 'cluster0-rh'][0]
        new_label_rh = right_label.copy()
        new_vertices_rh = np.array([i for j, i in enumerate(total_vertices) if j not in right_label.vertices])
        new_label_rh.vertices = new_vertices_rh
        new_label_rh.hemi = 'rh'
        new_label_rh.name = 'cluster0-rh'
        vertices_rh=new_label_rh.restrict(src).vertices

        vertices_network_lh.append(vertices_lh)
        vertices_network_rh.append(vertices_rh)
        np.save(save_path+network+'_'+'vertices_lh.npy',vertices_network_lh)
        np.save(save_path+network+'_'+'vertices_rh.npy',vertices_network_rh)
    all_network_vertices_lh.append([vertices_network_lh])
    all_network_vertices_rh.append([vertices_network_rh])
    gc.collect()
    return np.array(all_network_vertices_lh,dtype='object'),np.array(all_network_vertices_rh,dtype='object')


########## the below is for the labels that are restricted to the source space ##########
def get_vertices_first_network_src_restricted(networks_lh,networks_rh,src,save_path=None,network_names=None,save=True):
    """
    Parameters
    ----------
    networks_lh : list
        List of labels for each network in the left hemisphere.
    networks_rh : list
        List of labels for each network in the right hemisphere.
    src : instance of SourceSpaces
        Source space.

    Returns
    -------
    network_vertices : dict
        Dictionary of network vertices.
    """
    all_network_vertices_lh = []
    all_network_vertices_rh = []
    total_vertices = np.arange(src[0]['nuse'])##### Creating array for the subsampled vertices
    if save is True:
        if save_path is None:
            ValueError('Please specify a save path.')
        save_path = os.path.join(save_path, 'network_vertices/')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
    if network_names is None:
        network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
    for network in network_names:
        vertices_network_lh = []
        vertices_network_rh = []
        labels_lh=networks_lh[network_names.index(network)]
        left_label =[label for label in labels_lh if label.name == 'cluster0-lh'][0].restrict(src)
        new_label_lh = left_label.copy()
        new_vertices_lh = np.array([i for j, i in enumerate(total_vertices) if j not in left_label.vertices])
        new_label_lh.vertices = new_vertices_lh
        new_label_lh.hemi = 'lh'
        new_label_lh.name = 'cluster0-lh'
        vertices_lh=new_label_lh.vertices

        labels_rh=networks_rh[network_names.index(network)]
        right_label =[label for label in labels_rh if label.name == 'cluster0-rh'][0].restrict(src)
        new_label_rh = right_label
        new_vertices_rh = np.array([i for j, i in enumerate(total_vertices) if j not in right_label.vertices])
        new_label_rh.vertices = new_vertices_rh
        new_label_rh.hemi = 'rh'
        new_label_rh.name = 'cluster0-rh'
        vertices_rh=new_label_rh.vertices

        vertices_network_lh.append(vertices_lh)
        vertices_network_rh.append(vertices_rh)
        np.save(save_path+network+'_'+'vertices_lh.npy',vertices_network_lh)
        np.save(save_path+network+'_'+'vertices_rh.npy',vertices_network_rh)
        all_network_vertices_lh.append([vertices_network_lh])
        all_network_vertices_rh.append([vertices_network_rh])
    gc.collect()
    return np.array(all_network_vertices_lh,dtype='object'),np.array(all_network_vertices_rh,dtype='object')


def extract_sources_within_masks(source_data, mask_data):
    """
    Extract sources within masks from source data.

    Parameters
    ----------
    source_data : str
        The path to the reconstructed source data (STC file).
    mask_data : str
        The path to the mask data (source space file).

    Returns
    -------
    sources_within_masks : dict
        A dictionary of sources within each mask.
    """
    # Load the reconstructed source data
    stc = mne.read_source_estimate(source_data)

    # Load the mask data
    mask = mne.read_source_spaces(mask_data)

    # Extract the sources within each mask
    sources_within_masks = {}
    for label in mask.labels:
        label_name = label.name
        vertices = label.vertices
        masked_data = stc.copy().crop(None, None, vertices[0], copy=True)
        sources_within_mask = masked_data.extract_label_time_course([label_name], src=vertices, mode='mean')
        sources_within_masks[label_name] = sources_within_mask[0]

    return sources_within_masks

def get_vertices_of_network(network_name,src,mri_subject,mri_subjects_dir,Visualize= False,Debug_first_label=True):
    """
    **** Very Important . The parameter debug_first_label = True is only for Brainlabs parcellation where FS recognises the first parcellation as the full brain,
hence this is corrected by taking the remainin vertices of the brain after removal of first_parcellation(ONLY) AND THE REMAINDER IS TURNED INTO A PARCEL LABEL
    :param network_name:
    :param src:
    :param mri_subject:
    :param mri_subjects_dir:
    :param Visualize:
    :param Debug_first_label:
    :return:
    """
    ##### Loading Labels #####
    labels_rh = mne.read_labels_from_annot(mri_subject,parc=network_name, hemi='rh', surf_name='white',
                                        annot_fname=None, regexp=None, subjects_dir=mri_subjects_dir,
                                        sort=False, verbose=True)
    labels_lh = mne.read_labels_from_annot(mri_subject,parc=network_name, hemi='lh', surf_name='white',
                                        annot_fname=None, regexp=None, subjects_dir=mri_subjects_dir,
                                        sort=False, verbose=True)

    ##### Visualising ########## - Debug this later
    if Visualize:
        Brain = mne.viz.get_brain_class()
        brain = Brain(mri_subject, subjects_dir=mri_subjects_dir,
                      cortex='low_contrast', background='white', size=(800, 600))
        labels_tot = mne.read_labels_from_annot(mri_subject,parc=network_name, hemi='both', surf_name='white',
                                        annot_fname=None, regexp=None, subjects_dir=mri_subjects_dir,
                                        sort=False, verbose=True)
        brain.add_label(labels_tot, borders=False)
    ###### extracting vertices restricted to the source space ##### Using Restrict function

    vertices_rh=[label.restrict(src) for label in labels_rh]
    vertices_lh = [label.restrict(src) for label in labels_lh]
    ###### Visualising####  - Debug this later
    if Visualize:
        Brain = mne.viz.get_brain_class()
        brain = Brain(mri_subject, subjects_dir=mri_subjects_dir,
                      cortex='low_contrast', background='white', size=(800, 600))
        vis_rh = [label for label in vertices_rh]
        brain.add_label(vertices_rh, borders=False)
        brain.add_label(vertices_lh, borders=False)

    ###### appending to a single list ####
    array_vertices_rh=vertices_rh[0].vertices
    array_vertices_lh=vertices_lh[0].vertices
    for i in range(len(vertices_rh)-1):
        array_vertices_rh=np.append(array_vertices_rh,vertices_rh[i+1].vertices,axis=0)
        array_vertices_lh = np.append(array_vertices_lh, vertices_lh[i + 1].vertices,axis=0)

    return array_vertices_lh,array_vertices_rh

def extract_network_time_courses(array_vertices_lh,array_vertices_rh,stc):
    """
    Just to extract the corresponding time courses of a given network - This is followed By get vertices of a network code
    :param array_vertices_lh:
    :param array_vertices_rh:
    :param stc:
    :return:
    """
    lh_data=stc.lh_data[array_vertices_lh]
    rh_data=stc.rh_data[array_vertices_rh]
    return lh_data,rh_data

def nifti_to_labels(nifti_file_path,parcellation_name,mri_subject=None,mri_folder=None):
    atlas_img=nib.load(nifti_file_path)
    atlas_labels=mne.read_labels_from_annot(mri_subject,parc=atlas_img, hemi='both', surf_name='white',subjects_dir=mri_folder,verbose=True)
    labels_all= mne.read_labels_from_annot(subject=mri_subject, parc='aparc', hemi='both', surf_name='white', annot_fname=None, regexp=None, subjects_dir=mri_folder, sort=True, verbose=True)
    logging.info("Nifi to labels converted")
    return atlas_labels,atlas_img,labels_all

def get_vertices_src_for_prob_extraction(mri_subject,mri_subject_dir,save_path,src,save=True):
    """
    This function will extract the vertices of the first Cluster of the network labels in the restricted src space
    :param mri_subject:
    :param mri_subject_dir:
    :param save_path:
    :param src:
    :param save:1
    :return:
    """
    networks_lh,networks_rh,names,names_full = load_networks_hemi(mri_subject,mri_subject_dir,read_networks=True,surf_name='white')
    all_network_vertices_lh,all_network_vertices_rh = get_vertices_first_network_src_restricted(networks_lh,networks_rh,src,save_path=save_path,network_names=None,save=save)
    vertices_lh=np.empty(shape=(len(names)),dtype=object)
    vertices_rh=np.empty(shape=(len(names)),dtype=object)
    total_vertices_lh=np.empty(shape=1)
    total_vertices_rh=np.empty(shape=1)
    for name in names:
        logging.info("Extracting vertices for %s"%name)
        vertices_rh[names.index(name)]=all_network_vertices_rh[names.index(name)][0][0]
        vertices_lh[names.index(name)]=all_network_vertices_lh[names.index(name)][0][0]
        total_vertices_lh=total_vertices_lh+vertices_lh[names.index(name)].shape
        total_vertices_rh=total_vertices_rh+vertices_rh[names.index(name)].shape
    return vertices_lh,vertices_rh,total_vertices_lh,total_vertices_rh

def extract_probability_networks(probability,vertices_lh,vertices_rh,save_path,network_names=None,save=True):
    """
    This function will extract the probability of the network
    :param probability:
    :param vertices_lh:
    :param vertices_rh:
    :param network_names:
    :param save_path:
    :param save:
    :return:
    """
    if network_names is None:
        network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
    network_probability_lh=np.empty(shape=(len(network_names)),dtype=object)
    network_probability_rh=np.empty(shape=(len(network_names)),dtype=object)
    total_network_probability= np.empty(shape=(len(network_names)),dtype=object)
    for name in network_names:
        logging.info("Extracting probability for %s"%name)
        network_probability_lh[network_names.index(name)],network_probability_rh[network_names.index(name)]=extract_prob_of_network(vertices_lh[network_names.index(name)],vertices_rh[network_names.index(name)],probability=probability,sources_per_hemi=probability.shape[1]/2)
        total_network_probability[network_names.index(name)]=np.append(network_probability_lh[network_names.index(name)].astype('float'),network_probability_rh[network_names.index(name)].astype('float'),axis=1)
    network_probability_lh=np.reshape(network_probability_lh,(len(network_names),1))
    network_probability_rh=np.reshape(network_probability_rh,(len(network_names),1))
    total_network_probability=np.reshape(total_network_probability,(len(network_names),1))
    gc.collect()
    if save:
        save_path=os.path.join(save_path,"network_analysis/")
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        np.save(save_path+"network_probability_lh.npy",network_probability_lh)
        np.save(save_path+"network_probability_rh.npy",network_probability_rh)
        np.save(save_path+"total_network_probability.npy",total_network_probability)
    return total_network_probability

################# Calculation Functions ####################
def extract_prob_of_network(array_vertices_lh,array_vertices_rh,probability,sources_per_hemi):
    """ for the probability data .It will be as follows:
    Intial extraction was such that
    data = stc.lh_data
    rh_data = stc.rh_data
    data = np.append(data, rh_data,axis=0)
    hence the data indexing will be lh_data , rh_data
    hence indexing should be
    lh_data,rh_data + vertices_per_hemisphere(assumed identical)
    """
    network_probability_lh=probability[:,array_vertices_lh]
    array_vertices_rh2=array_vertices_rh+sources_per_hemi
    network_probability_rh=probability[:,array_vertices_rh]

    return network_probability_lh,network_probability_rh

def frequency_of_entering(network_probability_lh,network_probability_rh,network_name,time_points):
    total_probability_per_time=np.sum(network_probability_lh,axis=1)+np.sum(network_probability_rh,axis=1)
    assert time_points==network_probability_lh.shape[0]
    frequency =total_probability_per_time/time_points
    return frequency

def make_tpm_new(data,time_points,no_of_networks,diagonal=1,normalise=False):
    """
    data shape (num_of networks,No_of time points)
    This function was developed according to the ideas of Aidan and Andrea to have a more generalised TPM.
    It uses the methodology employed in
    However it was modified to be used in the context of our analysis
    - DK
    Args:
        data: The probability time series will be the input
        diagonal:Choice to have diagonal(Value =1) or not (Value =0)
        normalise:Choice to normalise the probabilities(Row wise/column wise) (1=True/0=False)

    Returns: Generated TPM with a Matrix of Size Input*Input

    """
    if data.shape[0]==no_of_networks:
        None
    else:
        data=data.transpose()

    size=data.shape[0]
    assert data.shape[0]==no_of_networks
    assert data.shape[1]==time_points
    tpm = np.zeros((size,size)) # Assumes the rows are sources
    for alpha in range(size):
        #iterating over networks
        Paa = data[alpha]
        Paa_sum = np.sum(Paa) / data.shape[1]
        for beta in range(size):
            #per network alpha,we iterate through betas
            t_array=np.delete(data[alpha],-1)
            t1_array=np.delete(data[beta],0)
            Pab =t_array*t1_array
            Pab_sum =np.sum(Pab)/(data.shape[1]-1)
            Wab=Pab_sum/Paa_sum
            tpm[alpha,beta]=Wab
    if diagonal==1: #diagonalize the TPM
        None
    else:
        None

    if normalise: # Normalize TPM
        #This normalisation is donw in the axis=0 , since axis=1 is already normalised
        Norm_const= np.sum(tpm,axis=0)
        new_tpm =tpm/Norm_const
    else:
        new_tpm=tpm

    return new_tpm
def make_tpm_new_object(Total_network_probability,time_points,no_of_networks,diagonal=True,normalise=False,Calculate_per_unit_source=False):
    """
    data shape (num_of networks,No_of time points)
    This function was developed according to the ideas of Aidan and Andrea to have a more generalised TPM.
    It uses the methodology employed in
    However it was modified to be used in the context of our analysis
    - DK
    Args:
        data: The probability time series will be the input
        diagonal:Choice to have diagonal(Value =1) or not (Value =0)
        normalise:Choice to normalise the probabilities(Row wise/column wise) (1=True/0=False)

    Returns: Generated TPM with a Matrix of Size Input*Input

    """
    data=Total_network_probability
    if data.shape[0]==no_of_networks:
        None
    else:
        data=data.transpose()
        logging.info("The data was transposed to match the number of networks")

    size=data.shape[0]
    assert data.shape[0]==no_of_networks
    if data[0][0].shape[0]==time_points:
        transpose=True
        logging.info("The data was transposed to match the number of time points")
    elif data[0][0].shape[1]==time_points:
        transpose=False
        logging.info("The data was not transposed since the time points are matching")
    else:
        logging.error("The time points are not matching Please check the data")
        logging.info("Redo Analysis")
    tpm = np.zeros((size,size))
    tpm_per_source=np.zeros((size,size))
    # Assumes the rows are sources
    network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial',
                     'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
    data2=np.empty(shape=(no_of_networks,time_points),dtype=object)
    data2_per_source=np.empty(shape=(no_of_networks,time_points),dtype=object)
    frequency_of_entering_values=np.empty(shape=(no_of_networks,1),dtype=object)
    frequency_of_entering_values_per_source=np.empty(shape=(no_of_networks,1),dtype=object)
    for name in network_names:
        logging.info(f"The probability is summed over the sources of network  %s"%name)
        if transpose:
            data2[network_names.index(name)]=np.sum(data[network_names.index(name)][0].transpose(),axis=0)
            data2_per_source[network_names.index(name)]=np.sum(data[network_names.index(name)][0].transpose(),axis=0)/data[network_names.index(name)][0].shape[1]
            frequency_of_entering_values[network_names.index(name)]=np.sum(data[network_names.index(name)][0].transpose())/time_points
            frequency_of_entering_values_per_source[network_names.index(name)]=np.sum(data[network_names.index(name)][0].transpose())/(data[network_names.index(name)][0].shape[1]*time_points)
        else:
            data2[network_names.index(name)]=np.sum(data[network_names.index(name)][0],axis=0)
            data2_per_source[network_names.index(name)]=np.sum(data[network_names.index(name)][0],axis=0)/data[network_names.index(name)][0].shape[1]
            frequency_of_entering_values[network_names.index(name)]=np.sum(data[network_names.index(name)][0])/time_points
            frequency_of_entering_values_per_source[network_names.index(name)]=np.sum(data[network_names.index(name)][0])/(data[network_names.index(name)][0].shape[1]*time_points)
    for alpha in range(size):
        #iterating over networks
        Paa = data2[alpha]
        Paa_sum = np.sum(Paa) / time_points
        for beta in range(size):
            #per network alpha,we iterate through betas
            t_array=np.delete(data2[alpha],-1)
            t1_array=np.delete(data2[beta],0)
            t_array_per_source=np.delete(data2_per_source[alpha],-1)
            t1_array_per_source=np.delete(data2_per_source[beta],0)
            Pab =t_array*t1_array
            Pab_sum =np.sum(Pab)/(time_points-1)
            Pab_per_source =t_array_per_source*t1_array_per_source
            Pab_sum_per_source =np.sum(Pab_per_source)/(time_points-1)
            #### Please note that The probability is not divided by the total number of points. Need to add the
            ####
            ## After discussion with Andrea We decided to use the following TPM where we remove the Paa_sum division since it biases the TPM
            # Wab=Pab_sum/Paa_sum
            Wab=Pab_sum
            Wab_per_source=Pab_sum_per_source
            tpm[alpha,beta]=Wab
            tpm_per_source[alpha,beta]=Wab_per_source
    if diagonal: #diagonalize the TPM
        None
        logging.info("Diagonal is left on TPM")
    elif not diagonal:
        for alpha in range(size):
            tpm[alpha,alpha]=0

    if normalise: # Normalize TPM
        #This normalisation is donw in the axis=0 , since axis=1 is already normalised
        Norm_const= np.sum(tpm,axis=0)
        new_tpm =tpm/Norm_const
        logging.info("TPM is normalised")
    else:
        new_tpm=tpm
        logging.info("TPM is not normalised")
    gc.collect()
    return new_tpm,tpm_per_source,frequency_of_entering_values,frequency_of_entering_values_per_source
####################### lOAD ALL Networks ############################

def get_tpm_and_frequency_of_entering(total_network_probability,time_points,network_names=None,diagonal=1,normalise=False):
    if network_names is None:
        network_names = ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience', 'smhand', 'smmouth', 'ventral', 'frontoparietal']
    assert time_points==total_network_probability[0].shape[0]
    no_of_networks=len(network_names)
    tpm=make_tpm_new_object(total_network_probability,time_points,no_of_networks,diagonal=diagonal,normalise=normalise)
    frequency_of_entering_networks=np.empty(shape=(len(network_names)),dtype=object)
    for name in network_names:
        logging.info("Extracting frequency of entering for %s"%name)
        frequency_of_entering_networks[network_names.index(name)]=frequency_of_entering(total_network_probability[network_names.index(name)][0][:,0:time_points],total_network_probability[network_names.index(name)][0][:,time_points:],name,time_points)
    frequency_of_entering_networks=np.reshape(frequency_of_entering_networks,(len(network_names),1))
    return tpm,frequency_of_entering_networks

#####################  TPM Functions #########################
#### Combining all Important functions above to get TPM and Frequency of Entering ####


##### LOAD ALL NETWORKS #####
##### TOTAL Network Probability #####

##### TPM OBJECT CODE NEW ####

def tpm_pipeline_surface(QM_save_path,src,probability,time_points,mri_subject_dir,mri_subject='fsaverage'):
    vertices_lh,vertices_rh,total_vertices_lh,total_vertices_rh = get_vertices_src_for_prob_extraction(mri_subject,mri_subject_dir,QM_save_path,src,save=True)
    total_network_probability = extract_probability_networks(probability,vertices_lh,vertices_rh,QM_save_path,network_names=None,save=True)
    new_tpm,tpm_per_source,frequency_of_entering_values,frequency_of_entering_values_per_source = make_tpm_new_object(Total_network_probability=total_network_probability,time_points=time_points,no_of_networks=12,diagonal=True,normalise=False,Calculate_per_unit_source=False)
    gc.collect()
    return new_tpm,tpm_per_source,frequency_of_entering_values,frequency_of_entering_values_per_source

################## Bonferoni Correction ###############