import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import mne

def animate_3d_scatter(x, y, z, frame_rate=50, auto_play=False):
    """
    Create an animated 3D scatter plot from x, y, and z time series arrays.

    Parameters:
        x (array-like): The x-coordinates of the points.
        y (array-like): The y-coordinates of the points.
        z (array-like): The z-coordinates of the points, as a 2D array with shape (n_frames, n_points).
        frame_rate (int, optional): The frame rate of the animation, in milliseconds per frame. Default is 50.
        auto_play (bool, optional): Whether to automatically start playing the animation when the HTML file is opened. Default is False.

    Returns:
        Graph object
    """
    # Get the number of points and frames
    n_points = len(x)
    n_frames = len(z)

    # Create a 3D scatter plot
    fig = go.Figure(
        data=[go.Scatter3d(x=x, y=y, z=z[0], mode='markers',marker=dict(color=z[0],colorscale='jet'))],
        layout=go.Layout(scene=dict(xaxis_title='X', yaxis_title='Y', zaxis_title='Z')),
    )

    # Define the frames for the animation
    frames = [go.Frame(data=[go.Scatter3d(x=x, y=y, z=z[k], mode='markers',marker=dict(color=z[k],colorscale='jet'))],
                       layout=go.Layout(scene=dict(xaxis_title='X', yaxis_title='Y', zaxis_title='Z')),
                       name=str(k)) for k in range(n_frames)]

    slider = dict(
        active=0,
        steps=[dict(label=str(k), method="animate", args=[[str(k)], {"frame": {"duration": 0, "redraw": True}, "mode": "immediate", "transition": {"duration": 0}}]) for k in range(n_frames)],
        x=0.1,
        y=0,
        len=0.9,
        transition={"duration": 0},
        currentvalue={"font": {"size": 20}, "prefix": "Time_Point: ", "visible": True, "xanchor": "center"},
        visible=True
    )
    # Define the slider

    # Define the play and pause buttons
    play_button = dict(
        buttons=[dict(label='Play',
                      method='animate',
                      args=[None,
                            {"frame": {"duration": frame_rate, "redraw": True},
                             "fromcurrent": True,
                             "transition": {"duration": 0}}]),
                 dict(label='Pause',
                      method='animate',
                      args=[[None],
                            {"frame": {"duration": 0, "redraw": False},
                             "mode": "immediate",
                             "transition": {"duration": 0}}])]
    )

    # Add the frames, slider, and buttons to the figure
    fig.update(frames=frames)
    x_range = [np.min(x), np.max(x)]
    y_range = [np.min(y), np.max(y)]
    z_range = [np.min(z), np.max(z)]
    fig.update_layout(scene=dict(xaxis_range=x_range, yaxis_range=y_range, zaxis_range=z_range))
    fig.update_layout(sliders=[slider], updatemenus=[play_button])

    return fig
    # # Save the plot as an HTML file
    # pio.write_html(fig, 'my_animation.html', auto_play=auto_play)
    #
    # # Show the plot
    # fig.show()

def plot_phase_space(x,px, p, pp, avg_x, avg_p, filename=None):
    # Calculate the probability density for position and momentum
    # Set up the figure
    fig, ax = plt.subplots(figsize=(8, 6))

    # Plot the position and momentum probability density
    ax.contourf(x, p, pp, 100, cmap='viridis')
    ax.contourf(x, p, px, 100, cmap='inferno', alpha=0.8)

    # Plot the average position and momentum
    ax.axvline(avg_x, linestyle='--', color='white', alpha=0.8, lw=1.5)
    ax.axhline(avg_p, linestyle='--', color='white', alpha=0.8, lw=1.5)

    # Set the axis labels and title
    ax.set_xlabel('Position', fontsize=14)
    ax.set_ylabel('Momentum', fontsize=14)
    ax.set_title('Phase Space Diagram', fontsize=16)

    # Set the colorbar
    cbar = plt.colorbar()
    cbar.ax.set_ylabel('Probability Density', fontsize=12)

    # Save or show the plot
    if filename is not None:
        plt.savefig(filename, dpi=300)
    else:
        plt.show()

def plot_montage(montage=False,raw=False):
    if raw==False:
        montage.plot()  # 2D
        fig = montage.plot(kind='3d', show=False)  # 3D
        fig = fig.gca().view_init(azim=70, elev=15)  # set view angle for tutorial
    if montage==False:
        fig = plt.figure()
        ax2d = fig.add_subplot(121)
        ax3d = fig.add_subplot(122, projection='3d')
        raw.plot_sensors(ch_type='eeg', axes=ax2d)
        raw.plot_sensors(ch_type='eeg', axes=ax3d, kind='3d')
        ax3d.view_init(azim=70, elev=15)

    return fig,ax3d,ax2d
# def get_data_plots(raw):
#
#     frequencies = np.arange(7, 30, 3)
#     power = mne.time_frequency.tfr_morlet(aud_epochs, n_cycles=2, return_itc=False,
#                                           freqs=frequencies, decim=3)
#     power.plot(['MEG 1332'])

def plot_brain_volume_sources(subject,subjects_dir,vol_src):
    plot_bem_kwargs = dict(
        subject=subject, subjects_dir=subjects_dir,
        brain_surfaces='white', orientation='coronal',
        slices=[50, 100, 150, 200])
    mne.viz.plot_bem(**plot_bem_kwargs)
    mne.viz.plot_bem(src=vol_src, **plot_bem_kwargs)
    return None


def mne_nilearn_plot(stc,src,mri_subject,mri_subject_dir):
    fig =stc.plot(src, subject=mri_subject, subjects_dir=mri_subject_dir, mode='glass_brain', bg_img='T1.mgz', colorbar=True, colormap='auto',
         clim='auto', transparent='auto', show=True, initial_time=None, initial_pos=None, verbose=True)
    return None