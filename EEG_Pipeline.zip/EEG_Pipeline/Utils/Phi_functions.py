import pyphi
import numpy as np
import pandas as pd
import cupy as cp
def distance_arrays(E, O, method=0):
    import numpy as np

    r = np.shape(E)[0]
    c = np.shape(E)[1]

    dif = 0

    # Element wise loop:
    if method != 2:
        for i in range(0, r):
            for j in range(0, c):
                if method == 0:
                    if E[i][j] == 0:
                        dif += np.abs((E[i][j] - O[i][j]) ** 2 / E[i][j])
                if method == 1:
                    dif += np.abs(E[i][j] - O[i][j])

    # F-norm (method 2 is absolute, method 3 is normalized).
    if method == 2:
        dif = np.sqrt(np.trace(np.matmul((E - O), np.transpose(E - O))))
    if method == 3:
        dif = np.sqrt(np.trace(np.matmul((E - O), np.transpose(E - O)))) / np.sqrt(np.trace(np.matmul(E, np.transpose(E))))

    return dif

def to_calculate_mean_phi(tpm, spin_mean, eps=None, out_type = "All"):
    import numpy as np
    import pyphi
    from pyphi.compute import phi

    rows, columns = tpm.shape

    setting_int = np.linspace(0, rows - 1, num=rows).astype(int)

    M = list(map(lambda x: list(pyphi.convert.le_index2state(x,5)), setting_int))
    M = np.asarray(M).astype(np.int)

    # num_states = np.log2(N)
    phi_values = []

    network = pyphi.Network(tpm)
    for state in range(rows):
        if eps == None:
            if spin_mean[state] != 0:
                print("Current state:")
                print(M[state, :])
                phi_values.append(phi(pyphi.Subsystem(network, M[state, :], range(network.size))))
        else:
            if spin_mean[state] < eps:
                phi_values.append(phi(pyphi.Subsystem(network, M[state, :], range(network.size))))

    weight = spin_mean[np.where(spin_mean != 0)]

    phiSum = np.sum(phi_values * weight)

    if out_type == "All":
        phi_values.append(phiSum)
        return phi_values
    else:
        return np.mean(phi_values), phiSum

def plot_prob(tpm, cutoff = 0.05):
    import numpy as np

    array_out = []

    n = np.shape(tpm)[0]
    for i in range(n):
        for j in range(n):
            if tpm[i, j] >= cutoff:
                array_out.append(tpm[i, j])

    return array_out

def swap_rows(timeseries):
    import numpy as np

    ts = np.copy(timeseries.T)  if timeseries.shape[1]>timeseries.shape[0] else np.copy(timeseries)
    len_ts = ts.shape[0]

    rand_num1 = np.random.randint(len_ts)
    rand_num2 = np.random.randint(len_ts)

    ts[[rand_num1, rand_num2],:] = ts[[rand_num2, rand_num1],:]

    return ts

def condense_dir_list(dir_list):
    list_new = []

    for d in dir_list:
        if d[0:2] != '._':
            if d != ".DS_Store":
                if d not in list_new:
                    list_new.append(d)

    return list_new


def calculate_phi(tpm, spin_mean, eps=None, out_type="All", plot_save_path=None):
    import numpy as np
    import pyphi
    import matplotlib.pyplot as plt

    # Check that tpm is a 2D array
    if len(tpm.shape) != 2:
        raise ValueError("tpm must be a 2D array")

    # Get network size from tpm
    N = tpm.shape[0]

    # Generate all possible network states
    setting_int = np.linspace(0, N-1, num=N).astype(int)
    M = list(map(lambda x: list(pyphi.convert.le_index2state(x, N)), setting_int))
    M = np.asarray(M).astype(np.int)

    # Calculate phi for each state
    phi_values = []
    network = pyphi.Network(tpm)
    for state in range(N**N):
        if eps == None or spin_mean[state] < eps:
            phi_values.append(pyphi.compute.phi(pyphi.Subsystem(network, M[state, :], range(network.size))))

    # Calculate mean phi
    weight = spin_mean[spin_mean != 0]
    phi_mean = np.sum(phi_values * weight) / np.sum(weight)

    # Visualize results
    plt.figure()
    plt.plot(M, phi_values, 'o-')
    plt.xlabel('Network state')
    plt.ylabel('Phi value')
    plt.title('Phi values for all network states')
    if plot_save_path is not None:
        plt.savefig(plot_save_path)

    # Output results
    if out_type == "All":
        phi_values.append(phi_mean)
        return phi_values
    else:
        return phi_mean




def calculate_mean_phi(tpm, states=None, eps=None, out_type='mean', save_loc=None):
    if not isinstance(tpm, np.ndarray):
        raise TypeError("tpm should be a CuPy array.")
    if tpm.ndim != 2:
        raise ValueError("tpm should be a 2D CuPy array.")
    if tpm.shape[0] != tpm.shape[1]:
        raise ValueError("tpm should be a square matrix.")
    if states is not None:
        if not isinstance(states, cp.ndarray):
            raise TypeError("states should be a CuPy array.")
        if states.ndim != 2 or states.shape[1] != tpm.shape[0]:
            raise ValueError("states should be a 2D CuPy array with dimensions (n_states, n_nodes).")
    else:
        states = np.asarray(pyphi.convert.le_index2state(np.arange(tpm.shape[0]), tpm.shape[1]))

    if eps is not None and not isinstance(eps, (float, np.floating, type(None))):
        raise ValueError("eps should be a float or None.")
    if out_type not in ['mean', 'all']:
        raise ValueError("out_type should be 'mean' or 'all'.")

    # Compute the phi values
    network = pyphi.Network(tpm)
    phi_values = []
    for i, state in enumerate(states):
        if eps is None or np.mean(state) < eps:
            subsystem = pyphi.Subsystem(network, state)
            subsystem.phi()
            phi_values.append(subsystem.phi)

    # Calculate the mean phi value
    mean_phi = np.mean(np.asarray(phi_values))

    # Save plot to given location if provided
    if save_loc is not None:
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots()
        ax.hist(np.asarray(phi_values), bins=20)
        ax.set_xlabel('Phi')
        ax.set_ylabel('Frequency')
        ax.set_title('Distribution of Phi Values')
        plt.savefig(save_loc)

    # Return the results
    if out_type == 'mean':
        return mean_phi
    else:
        return np.asarray(phi_values), mean_phi


print("Done!")










