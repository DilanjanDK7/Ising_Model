import os
import logging
import gc
import plotly.express as px
import mne
import numpy as np
from Utils.localization_func_with_reporting import *
from Utils.Ploting_functions import *
from Utils.QM_Model_functions import *
from Utils.Network_Extraction_TPM import *
from Utils.Telegram import *
import plotly.express as px
import gc
# Configuration
config = {
    'mri_subject': 'fsaverage',
    'mri_folder': '/home/brainlab-qm/FSL/Subjects_1',
    'eeg_file': '/home/brainlab-qm/EEG_test/Arci_test.set',
    'output_folder': '/home/brainlab-qm/EEG_test/Output',
    'eeg_subject': 'Arci_set',
    'forward_model_path': None,
    'calculate_TPM': True,
    'Time_limit': 40000,
    'network_names': ['auditory', 'visual', 'cingulooperc', 'cingulopari', 'default', 'dorsal', 'retrosplenial', 'salience',
                 'smhand', 'smmouth', 'ventral', 'frontoparietal']
}

# Enable garbage collector
gc.enable()

# Define paths
bem_dir = os.path.join(config['mri_folder'], config['mri_subject'], "Pipeline", "bem.fif")
source_space = os.path.join(config['mri_folder'], config['mri_subject'], "Pipeline", "source-src.fif")

# Create directories
folder = os.path.join(config['output_folder'], config['eeg_subject'])
os.makedirs(folder, exist_ok=True)
qm_save_path = os.path.join(config['output_folder'], config['eeg_subject'], "QM_model/")
os.makedirs(qm_save_path, exist_ok=True)

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s',
                    handlers=[logging.StreamHandler(), logging.FileHandler(os.path.join(qm_save_path, 'QM_Brain.log'))])

# Perform source localization
stc_file = os.path.join(folder, 'source')
if not os.path.isfile(stc_file + '-lh.stc'):
    try:
        logging.info("No stc file, Performing Source localization")
        stc = eeg_pipeline(config['eeg_file'], config['output_folder'], config['eeg_subject'], config['mri_subject'], config['mri_folder'], bem_dir=bem_dir,
                           source_space=source_space, forward_model_path=config['forward_model_path'], normalization_method='sloreta',
                           Time_limit=config['Time_limit'], report_path=folder)
        stc.save(stc_file, overwrite=True)
        del stc
    except Exception as e:
        logging.error(f"Error during source localization: {e}")
        send_message("Code error " + str(e))
    finally:
        gc.collect()

# Load source file
try:
    stc = mne.read_source_estimate(stc_file)
    logging.info(f"Source file loaded from {stc_file}")
    logging.info(f"file dimensions are {stc.data.shape}")
except Exception as e:
    logging.error(f"Error loading source file: {e}")
    send_message("Code error " + str(e))

# Get coordinates
try:
    x, y, z = get_coordinates_mni(stc, subject=config['mri_subject'], subjects_dir=config['mri_folder'])
    logging.info("Source localization Complete")
except Exception as e:
    logging.error(f"Error getting coordinates: {e}")
    send_message("Code error " + str(e))

# QM Model
try:
    No_of_sources, time_points = get_data_information(stc)
    logging.info(f"The Data has {No_of_sources} sources and {config['Time_limit']} Time points")
    data = extract_data(stc)
    X, Y, Z = mni_to_meters(x, y, z)
    px_vals, py_vals, pz_vals, len_kx, len_ky, len_kz = calc_k_space_3D(x, y, z, FOV_Red_Fac=1, Increment_Increase=0)
    QM_model_run(data, X, Y, Z, px_vals, py_vals, pz_vals, save_path=qm_save_path, time_points=time_points,
                 No_sources=No_of_sources, overwrite=True)
    gc.collect()
    probability = np.load(os.path.join(qm_save_path, "Probability_matrix.npy"))
    logging.info("QM Model Complete")
except Exception as e:
    logging.error(f"Error during QM Model: {e}")
    send_message("Code error " + str(e))

# Calculate TPM
if config['calculate_TPM']:
    try:
        logging.info("Calculating TPM")
        src = mne.read_source_spaces(source_space)
        tpm, tpm_per_source, frequency_of_entering_values, frequency_of_entering_values_per_source = tpm_pipeline_surface(
            QM_save_path=qm_save_path, src=src, probability=probability, time_points=time_points,
            mri_subject_dir=config['mri_folder'], mri_subject='fsaverage')
        logging.info("TPM Calculated")

        network_save = os.path.join(qm_save_path, "network_analysis/")
        os.makedirs(network_save, exist_ok=True)

        np.savetxt(os.path.join(network_save, "TPM.csv"), tpm)
        np.savetxt(os.path.join(network_save, "TPM_per_source.csv"), tpm_per_source)
        np.savetxt(os.path.join(network_save, "frequency_of_entering_values.csv"), frequency_of_entering_values)

        report_path = os.path.join(qm_save_path, "Plots/")
        os.makedirs(report_path, exist_ok=True)

        fig = px.imshow(tpm_per_source, x=config['network_names'], y=config['network_names'])
        fig.write_image(os.path.join(report_path, "tpm_per_source.png"))

        fig = px.imshow(tpm, x=config['network_names'], y=config['network_names'])
        fig.write_image(os.path.join(report_path, "tpm.png"))

        gc.collect()
    except Exception as e:
        logging.error(f"Error during TPM calculation: {e}")
        send_message("Code error " + str(e))

send_message(message="Code completed")
